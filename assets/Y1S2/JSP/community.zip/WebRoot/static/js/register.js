$(document).ready(function(){
//    $("#send").click(function(){
//        $("#send").success();
//    });
    $(this).check();
});