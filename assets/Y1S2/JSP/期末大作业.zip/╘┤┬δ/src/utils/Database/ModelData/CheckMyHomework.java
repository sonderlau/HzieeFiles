package utils.Database.ModelData;

public class CheckMyHomework {
    // TODO:
    // 检查作业
    // @param : LessonID 课程的ID
    // -> 班级ID -> 考虑 -> ArrangeFor
    // 属于级 但是不属于任何班的一个学生 怎么考虑
    // 如果做过 要找到他的成绩 返回

//    public static ArrayList<Homework> getHomeworkById(String LessonID){
//        // 通过ID 获取作业内容
//
//    }
}
