package site.hziee.sonderlau.demo;

public interface UserDao {
    public void save();
    public void delete();
}
