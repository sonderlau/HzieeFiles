package com.atguigu.springboot04webresultfulcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot04WebResultfulcrudApplicationTests {

    @Test
    void contextLoads() {
        System.out.println(1);
    }

}
