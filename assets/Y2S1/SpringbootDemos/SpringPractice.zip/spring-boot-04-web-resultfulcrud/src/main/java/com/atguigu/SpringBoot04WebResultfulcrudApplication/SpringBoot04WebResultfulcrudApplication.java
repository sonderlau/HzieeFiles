package com.atguigu.SpringBoot04WebResultfulcrudApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot04WebResultfulcrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBoot04WebResultfulcrudApplication.class, args);
    }

}
