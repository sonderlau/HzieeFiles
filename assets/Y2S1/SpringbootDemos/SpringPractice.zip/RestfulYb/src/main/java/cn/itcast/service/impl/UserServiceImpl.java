package cn.itcast.service.impl;

import cn.itcast.dao.UserDao;
import cn.itcast.pojo.User;
import cn.itcast.service.UserService;
import com.alibaba.fastjson.JSON;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("userService")
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    @Insert("insert into users(username, password) values (#{username}, #{password})")
    public int addUser(User user) {
        return userDao.addUser(user);
    }

    @Delete("delete from users where username = #{username}")
    public int deleteUserByUsername(String name) {
        return userDao.deleteUserByUsername(name);
    }

    @Update("update users set username = #{username} ,password = #{password } where id = #{id}")
    public int updateUser(User user) {
        return userDao.updateUser(user);
    }

    @Select("select username,password from users where id = #{id}")
    public User selectUserById(int id) {
        return userDao.selectUserById(id);
    }
}
