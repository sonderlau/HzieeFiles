package cn.itcast.service;

import cn.itcast.pojo.User;

public interface UserService {

    public int addUser(User user);
    public int deleteUserByUsername(String name);
    public int updateUser(User user);
    public User selectUserById(int id);
}
