package cn.itcast.dao;

import cn.itcast.pojo.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface UserDao {
    @Insert("insert into users(username, password) values (#{username}, #{password})")
    public int addUser(User user);
    @Delete("delete from users where username = #{username}")
    public int deleteUserByUsername(String name);
    @Update("update users set username = #{username} ,password = #{password } where id = #{id}")
    public int updateUser(User user);
    @Select("select username,password from users where id = #{id}")
    public User selectUserById(int id);
}
