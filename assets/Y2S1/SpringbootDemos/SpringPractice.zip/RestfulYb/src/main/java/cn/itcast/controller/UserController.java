package cn.itcast.controller;

import cn.itcast.pojo.User;
import cn.itcast.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping(value = "/add")
    public int addUser(@RequestParam(value = "username") String username,
                       @RequestParam(value = "password") String password) {
        User user = new User(username,password);
        return userService.addUser(user);
    }

    @RequestMapping(value = "/delete/{username}", method = RequestMethod.DELETE)
    @ResponseBody
    public int deleteUserByUsername(@PathVariable("username") String name) {
        userService.deleteUserByUsername(name);
        return 200;
    }


    @PostMapping(value = "/update")
    public int updateUser(@RequestParam(value = "username") String username,
                          @RequestParam(value = "password") String password) {
        User user = new User(username,password);
        userService.updateUser(user);
        return 200;
    }

    @RequestMapping(value = "/select/{id}", method = RequestMethod.GET)
    @ResponseBody
    public User selectUserById(@PathVariable("id") int id) {
        return userService.selectUserById(id);
    }
}
