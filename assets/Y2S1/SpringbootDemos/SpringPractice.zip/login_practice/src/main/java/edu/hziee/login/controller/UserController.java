package edu.hziee.login.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {

    private static final String DEFAULT_USERNAME = "admin";
    private static final String DEFAULT_PASSWORD = "123456";

    @RequestMapping("/login")
    public String login(@RequestParam("username")String loginName,
                       @RequestParam("password")String password){
        if ( DEFAULT_USERNAME.equals(loginName) && DEFAULT_PASSWORD.equals(password) ){
            return "ok.jsp";
        }else {
            return "error.jsp";
        }
    }
}
