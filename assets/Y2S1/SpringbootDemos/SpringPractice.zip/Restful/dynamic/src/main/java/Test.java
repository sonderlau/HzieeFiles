import Dao.UserMapper;
import Model.User;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import org.junit.Assert;
import org.junit.Before;

import java.io.InputStream;

import java.util.List;


public class Test {
    @Resource
    private UserMapper userMapper;
    @Before
    public void init(){
        //读取配置文件
        String resource = "mybaits.xml";
        InputStream is = this.getClass().getClassLoader().getResourceAsStream(resource);

        //创建SqlSessionFactory和SqlSession
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(is);
        SqlSession session = sessionFactory.openSession();
        userMapper = session.getMapper(UserMapper.class);


    }


    @org.junit.Test
    public void testSelectByUser() {

            // 只按用户名查询
            User query = new User();
            query.setUsername("ad");
            List<User> sysUserList = userMapper.selectByUser(query);
            Assert.assertTrue(sysUserList.size() > 0);

            // 只按邮箱查询
            query = new User();
            query.setEmail("test@mybatis.tk");
            sysUserList = userMapper.selectByUser(query);
            Assert.assertTrue(sysUserList.size() > 0);

            // 同时按用户民和邮箱查询
            query = new User();
            query.setUsername("ad");
            query.setEmail("test@mybatis.tk");
            sysUserList = userMapper.selectByUser(query);
            // 由于没有同时符合这两个条件的用户，因此查询结果数为0
            Assert.assertEquals(0, sysUserList.size());

    }

    @org.junit.Test
    public void testUpdateSelective(){
        User query = new User();
        query.setId(5);
        query.setEmail("test@mybatis.tk");

        int result = userMapper.updateByIdSelective(query);
        Assert.assertEquals(1, result);

        // 查询id=1的用户
        query = userMapper.selectById(1);
        // 修改后的名字保持不变，但是邮箱变成了新的
        Assert.assertEquals("admin", query.getUsername());
        Assert.assertEquals("test@mybatis.tk", query.getEmail());


    }

}
