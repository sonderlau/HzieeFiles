package Dao;

import Model.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {
    List<User> selectByUser(User user);
    int updateByIdSelective(User user);
    User selectById(int id);
}
