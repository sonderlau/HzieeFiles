package cn.itcast.dao;

import cn.itcast.pojo.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface UserMapper {
    public int addUser(User user);
    public int deleteUserByUsername(String name);
    public int updateUser(User user);
    public User selectUserById(int id);
}
