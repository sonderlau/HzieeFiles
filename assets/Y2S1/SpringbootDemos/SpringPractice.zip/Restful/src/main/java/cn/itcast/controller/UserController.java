package cn.itcast.controller;

import cn.itcast.pojo.User;
import cn.itcast.service.UserService;
import cn.itcast.utils.CommonResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {

    @Autowired
    private UserService userService;


    @RequestMapping(value = "/get/{id}", method = RequestMethod.GET)
    @ResponseBody
    public CommonResponse getUserById(@PathVariable("id") int id){
        return CommonResponse.success().add("User",userService.selectUserById(id));
    }
}
