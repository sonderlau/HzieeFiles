package cn.itcast.Impl;

import cn.itcast.pojo.User;
import cn.itcast.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserService userService;

    @Override
    public int addUser(User user) {
        userService.addUser(user);
        return 200;
    }

    @Override
    public int deleteUserByUsername(String name) {
        return 0;
    }

    @Override
    public int updateUser(User user) {
        return 0;
    }

    @Override
    public User selectUserById(int id) {
        return null;
    }
}
