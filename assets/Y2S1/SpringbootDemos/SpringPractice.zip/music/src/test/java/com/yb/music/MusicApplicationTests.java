package com.yb.music;

import com.yb.music.dao.SongDao;
import com.yb.music.dao.UserDao;
import com.yb.music.dao.UserSongDao;
import com.yb.music.entities.Song;
import com.yb.music.entities.User;
import com.yb.music.entities.UserSong;
import com.yb.music.service.UserService;
import com.yb.music.service.impl.UserServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MusicApplication.class,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MusicApplicationTests {

    @Resource
    private UserSongDao userSongDao;

    @Resource
    private SongDao songDao;

   @Test
    public void contextLoads() {
       //查询对应openid所对应的所有歌曲
       List<UserSong> userSongList = userSongDao.findAllSongIdByOpenId("123");
       //创建一个歌曲列表
       List<Song> songList = new ArrayList<>();
       for (int i = 0; i < userSongList.size() ; i++) {
           Song song = songDao.findAllSongsById(Integer.parseInt(userSongList.get(i).getSong_id()));
           songList.add(song);
       }
       System.out.println("**********"+userSongList.size());
       System.out.println(songList);
    }

}
