package com.yb.music.service.impl;

import com.yb.music.dao.UserDao;
import com.yb.music.entities.User;
import com.yb.music.service.UserService;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserDao userDao;


    @Override
    public User selectByNameAndPsw(String userId,String password) {
        return userDao.selectByNameAndPsw(userId,password);
    }

    @Override
    public User findByUserId(String userId) {
        return userDao.findByUserId(userId);
    }
}
