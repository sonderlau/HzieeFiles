package com.yb.music.entities;


import lombok.Data;

//歌曲
@Data
public class Song {
    private Integer id;
    private String title;
    private String author;
    private String lyric;
    private String album;
    private String src;
}
