package com.yb.music.entities;

import lombok.Data;

//现在播放的歌曲列表
@Data
public class CurrentSong {
    private Integer id;
    private String openid;
    private int current;
}
