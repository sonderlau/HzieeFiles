package com.yb.music.dao;

import com.yb.music.entities.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Mapper
public interface UserDao{

    @Select("select * from user")
    User findAll();

    @Select("select * from user where user_id = #{userId} and password = #{password}")
    User selectByNameAndPsw(@Param("userId") String userId,@Param("password") String password);

    @Select("select * from user where user_id = #{userId}")
    User findByUserId(String userId);

    @Update("update user set user_id=#{userId1} where user_id=#{userId2}")
    int updateUserIDByUserId(@Param("userId1") String userId1,@Param("userId2") String userId2);

    @Update("update user set password=#{password1} where password=#{password2}")
    int updatePWDByUserId(@Param("password1") String password1,@Param("password2") String password2);
}
