package com.yb.music.controller;

import com.yb.music.dao.CurrentSongDao;
import com.yb.music.dao.SongDao;
import com.yb.music.dao.UserDao;
import com.yb.music.dao.UserSongDao;
import com.yb.music.dto.SongList;
import com.yb.music.entities.CommonResult;
import com.yb.music.entities.CurrentSong;
import com.yb.music.entities.Song;
import com.yb.music.entities.UserSong;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/music")
public class SongListController {

    @Resource
    private UserSongDao userSongDao;

    @Resource
    private SongDao songDao;

    @Resource
    private CurrentSongDao currentSongDao;

    //根据对应的openid返回对应的歌曲列表
    @GetMapping("/playlist")
    public CommonResult PlayList(@RequestParam("openid") String openid){
        //查询对应openid所对应的所有歌曲
        List<UserSong> userSongList = userSongDao.findAllSongIdByOpenId(openid);
        //创建一个歌曲列表
        List<Song> songList = new ArrayList<>();
        for (int i = 0; i < userSongList.size() ; i++) {
            Song song = songDao.findAllSongsById(Integer.parseInt(userSongList.get(i).getSong_id()));
            songList.add(song);
        }
        //获得之前歌曲历史记录
        int id = currentSongDao.findByOpenId1(openid).getCurrent();
        SongList songList1 = new SongList();
        songList1.setCurrent(id);
        songList1.setList(songList);
        return new CommonResult(200,openid,songList1);
    }

    //根据openid和song_id添加歌曲曲目
    @GetMapping("/addSong")
    public CommonResult AddSong(@RequestParam(value = "openid",required = false) String openid,
                                @RequestParam(value = "id",required = false) String id){
        //先查找是否存在这个openid
        int id1 = Integer.parseInt(id);
        int result = userSongDao.findAllSongIdByOpenId1(openid).size();
        //查询是否存在对应用户的歌曲
        int result1 = userSongDao.findAllSongIdByOpenIdAndSongId(openid, id1).size();
        //查询已有歌曲数目
        List<UserSong> userSongList = userSongDao.findAllSongIdByOpenId(openid);
        if(result>0){
            //如果存在这个openid，查询是否存在这首歌
            if(result1>0){
                //存在这首歌的时候，更改听歌记录
                currentSongDao.updateByOpenId(openid,id1);
                return new CommonResult(200,openid,null);
            }else {
                //不存在这首歌的时候
                if(userSongList.size()==9) {
                    userSongDao.deleteById(userSongList.get(0).getId());
                    currentSongDao.updateByOpenId(openid,id1);
                    userSongDao.insertSongBySongId(openid, id1);
                    return new CommonResult(200, openid, null);
                }else {
                    currentSongDao.updateByOpenId(openid,id1);
                    userSongDao.insertSongBySongId(openid, id1);
                    return new CommonResult(200, openid, null);
                }
            }
        }else {
            //增加用户听歌记录
            currentSongDao.insertLastSong(openid,id1);
            //增加用户的播放列表
            userSongDao.insertSongBySongId(openid,id1);
            return new CommonResult(200,openid,null);
        }
    }

}
