package com.yb.music.dto;

import com.yb.music.entities.Song;
import lombok.Data;

import java.util.List;

//推荐歌曲
@Data
public class SongList {
    private Integer current;
    private List<Song> list;
}
