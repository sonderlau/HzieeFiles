package com.yb.music.dao;

import com.yb.music.entities.Song;
import com.yb.music.entities.UserSong;
import org.apache.ibatis.annotations.*;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Mapper
public interface UserSongDao {

    @Select("select * from user_song where openid = #{openid}")
    List<UserSong> findAllSongIdByOpenId(@Param("openid") String openid);

    @Insert("insert into user_song(openid,song_id) values(#{openid},#{id})")
    int insertSongBySongId(@Param("openid") String openid,@Param("id") Integer id);

    @Select("select * from user_song where openid = #{openid}")
    List<UserSong> findAllSongIdByOpenId1(@Param("openid") String openid);

    @Select("select * from user_song where openid = #{openid} and song_id = #{id}")
    List<UserSong> findAllSongIdByOpenIdAndSongId(@Param("openid") String openid,@Param("id") Integer id);

    @Delete("delete from user_song where id=#{id}")
    int deleteById(@Param("id") Integer id);
}
