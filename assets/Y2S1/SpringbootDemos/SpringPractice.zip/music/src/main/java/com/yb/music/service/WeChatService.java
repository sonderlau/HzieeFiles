package com.yb.music.service;

import com.yb.music.entities.CommonResult;
import org.apache.ibatis.annotations.Param;

public interface WeChatService {

    CommonResult codeopenid(String code) throws Exception;
}
