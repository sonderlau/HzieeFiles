package com.yb.music.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CommonResult<T> {

    private Integer errorCode;
    private String openid;
    private T       data;

    public CommonResult(Integer errorCode, String openid) {
        this.errorCode = errorCode;
        this.openid = openid;
        this.data = null;
    }
}
