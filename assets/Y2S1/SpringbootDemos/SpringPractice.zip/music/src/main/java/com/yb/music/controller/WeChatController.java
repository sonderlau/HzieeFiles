package com.yb.music.controller;

import com.alibaba.fastjson.JSONObject;
import com.yb.music.entities.CommonResult;
import com.yb.music.service.WeChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


//登入
@RestController
public class WeChatController {
    @Autowired
    WeChatService wc;

    @RequestMapping("/cis")
    public CommonResult getCode(@RequestParam(value = "code")String  code) throws Exception {
        System.out.println(code);
        return wc.codeopenid(code);
    }
}
