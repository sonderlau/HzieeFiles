package com.yb.music.dao;

import com.yb.music.entities.Song;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface SongDao {

    @Select("select * from song where id = #{id}")
    Song findAllSongsById(@Param("id") Integer id);

    @Select("select * from song")
    List<Song> findAllSongs();
}
