package com.yb.music.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yb.music.entities.CommonResult;
import com.yb.music.service.WeChatService;
import com.yb.music.utils.SslUtil;
import com.github.kevinsawicki.http.HttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Service
public class WeChatServiceImpl implements WeChatService {


    @Override
    @ResponseBody
    public CommonResult codeopenid(String code) throws Exception {
        Map<String, String> data = new HashMap<String, String>();
        data.put("appid", "wx5cfbc2435df202da");
        data.put("secret", "2b92960a598235e72d361873a4fee4bb");
        data.put("js_code", code);
        data.put("grant_type", "authorization_code");
        SslUtil.ignoreSsl();
        String response = HttpRequest.get("https://api.weixin.qq.com/sns/jscode2session").form(data).body();
        System.out.println("Response was: " + response);
        JSONObject obj= JSON.parseObject(response);//将json字符串转换为json对
        if (obj.containsKey("openid")){
            //return RetResponse.makeOKRsp(obj);
            return new CommonResult(200,null,obj);
        }
        else {
            //return RetResponse.makeErrRsp(obj.get("errmsg").toString());

        }
        return new CommonResult(444,null);
    }
}
