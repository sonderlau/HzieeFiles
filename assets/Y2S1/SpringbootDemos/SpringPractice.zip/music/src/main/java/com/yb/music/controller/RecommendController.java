package com.yb.music.controller;

import com.yb.music.dao.SongDao;
import com.yb.music.entities.CommonResult;
import com.yb.music.entities.Song;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/music")
public class RecommendController {

    @Resource
    private SongDao songDao;


    @GetMapping("/recommendList")
    public CommonResult RecommendList(){
        List<Song> songs = songDao.findAllSongs();
        List<List<Song>> lists = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            List<Song> list = new ArrayList<>();
            for (int j = 0; j < 6; j++) {
                Random random = new Random();
                Song song = songs.get(random.nextInt(songs.size()));
                if(!list.contains(song)) {
                    list.add(song);
                }else {
                    j--;
                }
            }
            lists.add(list);
        }
        return new CommonResult(200,null,lists);
    }
}
