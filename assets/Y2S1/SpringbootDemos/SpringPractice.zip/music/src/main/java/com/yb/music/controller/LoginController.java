package com.yb.music.controller;

import com.yb.music.dao.UserDao;
import com.yb.music.entities.CommonResult;
import com.yb.music.entities.User;
import com.yb.music.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;


@Slf4j
@RestController
@RequestMapping("/music")
public class LoginController {

    @Resource
    private UserService userService;

    @Resource
    private UserDao userDao;

    //登录页
    @PostMapping(value = { "/login" })
    public CommonResult login(@RequestParam(value = "userId",required = false) String userId,
                              @RequestParam(value = "password",required = false) String password){

        log.info("********************"+userId);
        log.info("********************"+password);
        User getUser = userService.selectByNameAndPsw(userId,password);
        //查询输入信息是否存在
        if (getUser != null){
            User user = userService.findByUserId(getUser.getUser_id());
            return new CommonResult(200,user.getUser_uuid(),null);
        }
        else{
            //return RetResponse.makeErrRsp("用户名或密码错误");//登陆失败
            return new CommonResult(204,"用户名或密码错误");
        }
    }


    //修改信息
    @PutMapping("/edit")
    public CommonResult edit(@RequestParam("type") String type,@RequestParam("current") String current,@RequestParam("value") String value){
        if (type == "ID"){
            userDao.updateUserIDByUserId(value,current);
            return new CommonResult(200,null);
        }
        if (type == "PW"){
            userDao.updateUserIDByUserId(value,current);
            return new CommonResult(200,null);
        }
        return new CommonResult(444,null);
    }
}
