package com.yb.music.entities;

import lombok.Data;

@Data
public class UserSong {
    private Integer id;
    private String openid;
    private String song_id;
}
