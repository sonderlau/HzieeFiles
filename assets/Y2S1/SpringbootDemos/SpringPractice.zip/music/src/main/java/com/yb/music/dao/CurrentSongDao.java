package com.yb.music.dao;

import com.yb.music.entities.CurrentSong;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Service;

@Mapper
public interface CurrentSongDao {

    @Select("select + from current_song where openid = #{openid}")
    int findByOpenId(@Param("openid") String openid);

    @Insert("insert into current_song(openid,current) values(#{openid},#{id})")
    int insertLastSong(@Param("openid") String openid,@Param("id") Integer id);

    @Select("select * from current_song where openid = #{openid}")
    CurrentSong findByOpenId1(@Param("openid") String openid);

    @Update("update current_song set current=#{id} where openid=#{openid}")
    int updateByOpenId(@Param("openid") String openid,@Param("id") Integer id);
}
