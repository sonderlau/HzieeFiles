/**
 * 单链表
 * @param <E>
 */
public class SingleLinkedList<E>  {
    private ListNode<E> head;
    private int size;
    public SingleLinkedList(){}
    public SingleLinkedList(ListNode<E> node){
        this.head = node;
        size ++;
    }

    public void insert(ListNode<E> node) {
        insertNth(node,size);
    }


    public void insertHead(ListNode<E> node) {
        insertNth(node,0);
    }


    public void insertNth(ListNode<E> ListNode, int position) {
        if (head == null){ // 空链表
            throw new NullPointerException("链表为空");
        }
        if (position == 0){ // 头节点
            ListNode.next = head;
            head = ListNode;
            size++;
            return;
        }
        checkBounds(position,0,size); // 检查是否越界
        ListNode<E> point = head;
        for (int i = 0;point.next != null; point = point.next, i++){
            if (i == position-1){ // 插入位置的前一个节点
                ListNode.next = point.next;
                point.next = ListNode;
            }
        }
        size++;
    }

    public int search(ListNode<E> ListNode){
        int count = 0;
        ListNode<E> temp = head;
        for (;temp.next != null; temp = temp.next ){
            if (temp == ListNode)
                return count;
            count++;
        }
        return -1;
    }

    public int searchByValue(E value){
        ListNode<E> temp = head;
        int count = 0;
        for (;temp.next != null; temp = temp.next){
            if (temp.value == value){
                return count;
            }
            count ++;
        }
        return -1;
    }


    public void delete() {
        deleteNth(size-1);
    }


    public void deleteHead() {
        deleteNth(0);
    }


    public void deleteNth(int position) {
        if (head == null){ // 空链表
            throw new NullPointerException("链表为空");
        }
        if (position == 0){ // 头节点
            head = head.next;
            size--;
            return;
        }
        checkBounds(position,0,size); // 检查是否越界
        ListNode<E> point = head;
        for (int i = 0;point.next != null; point = point.next, i++){
            if (i == position-1){ // 删除位置的前一个节点
                point.next = point.next.next;
            }
        }
        size--;
    }


    public void checkBounds(int position, int low, int high) {
        if (position < low || position > high){
            throw new IndexOutOfBoundsException("链表长度越界");
        }
    }


    public void clear() {
        this.head = null;
        // 剩下的交给垃圾处理器
    }


    public boolean isEmpty() {
        return this.head == null;
    }


    public int size() {
        return size;
    }


    public ListNode<E> getHead() {
        return head;
    }



    public ListNode<E> getNth(int position) {
        checkBounds(position,0,size);
        ListNode<E> point = head;
        for (int i = 0; point.next != null; point = point.next ){
            if (i == position - 1){
                return point;
            }
        }
        return null;
    }

    /**
     * 返回头节点
     * @return 头节点
     */
    public ListNode<E> first() {
        return head.next;
    }


    public ListNode<E> next(ListNode<E> p) {
        return p.next;
    }


    public ListNode<E> previous(ListNode<E> p) {
        int foundedPosition = search(p);
        checkBounds(foundedPosition,0,size);
        return getNth(foundedPosition);

    }

    /**
     * 返回尾节点
     * @return 节点
     */
    public ListNode<E> last() {
        return getNth(size);
    }


    /**
     * 删除所有值 为 key 的节点
     * @param key 值
     */
    public void removeAll(E key) {
        ListNode<E> temp = head;
        int count = 0;
        for (;temp.next != null; temp = temp.next){
            if (temp.value == key){
                deleteNth(count);
            }
            count ++;
        }
    }


    /**
     * 将链表中所有值为 key 的节点中的值 替换为 x
     * @param key 值
     * @param x   值
     */
    public void replaceAll(E key, E x) {
        ListNode<E> temp = head;
        for (;temp.next != null; temp = temp.next){
            if (temp.value == key){
                temp.value = x;
            }
        }
    }


    /**
     * 裁剪链表
     * @param begin  起始位置
     * @param end    结束位置
     * @return       链表
     */
    public SingleLinkedList<E> subList(int begin, int end) {
        return this.remove(0,begin-1).remove(end+1,size);
    }


    /**
     * 删除 begin 到 end 中的节点
     * @param begin  起始位置
     * @param end    结束位置
     * @return       链表
     */
    public SingleLinkedList<E> remove(int begin, int end) {
        checkBounds(begin-1, 0, size);
        checkBounds(end +1, 0, size);
        getNth(begin -1).next = getNth(end+1);
        return this;
    }


    /**
     * 检查链表中是否包括 给定链表中的节点
     * @param list  提供数据的链表
     * @return      是否包含
     */
    public boolean contains(SingleLinkedList<E> list) {
        for (ListNode<E> temp = list.head; temp.next != null; temp = temp.next){
            if (search(temp) == -1) return false;
        }
        return true;
    }

    /**
     * 将链表中的全部内容都添加到某个位置之后
     * @param i     位置
     * @param list  链表
     */
    public void addAll(int i, SingleLinkedList<E> list) {
        // 检查长度
        checkBounds(i,0,size);
        ListNode<E> nextOne = getNth(i);
        nextOne.next = list.head;
        list.getNth(list.size).next = nextOne;
    }

    /**
     * 合并两个节点
     * @param list  链表
     * @return      合并之后的节点
     */
    public SingleLinkedList<E> union(SingleLinkedList<E> list) {
        this.addAll(size,list);
        return this;
    }


    public void substract(SingleLinkedList<E> list) {

    }

    public SingleLinkedList<E> difference(SingleLinkedList<E> list) {
        // todo: 采用heap排序后
        return null;
    }

    public void retainAll(SingleLinkedList<E> list) {

    }

    public SingleLinkedList<E> intersection(SingleLinkedList<E> list) {
        return null;
    }


    public ListNode<E> search(SingleLinkedList<E> pattern) {
        return null;
    }


    public void removeAll(SingleLinkedList<E> pattern) {

    }


    public void replaceAll(SingleLinkedList<E> pattern, SingleLinkedList<E> list) {

    }
}
class ListNode<E> {
    E value;
    ListNode<E> next;
    ListNode(){

    }
    ListNode(E e){
        this.value  = e;
    }
    ListNode (E value,ListNode<E> next){
        this.value = value;
        this.next = next;
    }
}
