public class SequentialList<T> {
    private int length;                          // 数组的长度
    private static final int DEFAULT_LENGTH = 10;
    private int element_num = 0;                 // 元素的个数
    private T[] data_list;



    SequentialList() {
        // this.data_list = new T[DEFAULT_LENGTH];
        this.length = DEFAULT_LENGTH;
    }
    SequentialList(int length){
        if (length > 0) {
            // this.data_list = new T[length*1.5 > DEFAULT_LENGTH ? (int) (length * 1.5) : DEFAULT_LENGTH];
            this.length = (int) (length*1.5);
        }
    }

    
//    public void grow() {
//        // Object[] newCapacityList = new T[(int) (length*1.5)];
//        // for (int i = 0; i < this.data_list.length ; i ++) {
//            // newCapacityList[i] = this.data_list[i];
//        }
//        // this.data_list = newCapacityList;
//
//    }
    
    public boolean isEmpty() {
        return data_list == null;
    }

    
    public int size() {
        return element_num;
    }

    
    public Object get(int i) {
        return data_list[i];
    }

    
    public void set(int index, T x) {
        data_list[index] = x;
    }
    
    public void insert(int index, T x) {
        // 索引位置检查
        if (index < 0 || index > length -1) {
            System.out.println("数组越界");
            return;
        }
        // 数组长度检查
    }

    
    public int insert(T element) {
        data_list[element_num] = element;
        element_num ++;
        return element_num;
    }

    
    public Object remove(int index) {
        return null;
    }

    
    public void clear() {
        data_list = null;
        length = 0;
    }

    
    public int search(Object key) {
        return 0;
    }

    
    public boolean contains(Object key) {
        return false;
    }

    
    public Object remove(Object key) {
        return null;
    }

    public void removeAll(T key) {

    }
    public void replaceFirst(T key, T x) {

    }

    public void replaceAll(T key, T x){

    }
    public int searchLast(T key){
        return 0;
    }
    public void removeLast(T key){

    }
    public void reoplaceLast(T key, T x){

    }

    /**
     * 添加新的顺序表到当前的表尾
     * @param list  待添加的顺序表
     * @return      添加好的顺序表
     */
    public SequentialList<T> addAll(SequentialList<T> list){
        int newLength = (int) ((list.length + this.length) * 1.5);
        SequentialList<T> newElementArray = new SequentialList<>();
        for (int i = 0; i < list.length+this.length; i++) {
            if (i < this.length){
                newElementArray.insert(this.data_list[i]);
            }else {
                newElementArray.insert(this.data_list[i - this.length]);
            }
        }
        return newElementArray;
    }


}
