package D4;

import SingleLinkedList;

public class D4<E>{
	public static void main(String[] args) {
		
	}
//	public SingleLinkedList<E> mergeLinkedListByPlus(SingleLinkedList<E> a, SingleLinkedList<E> b){
//
//	}
//	public SingleLinkedList<E> mergeLinkedListByMultiply(SingleLinkedList<E> a, SingleLinkedList<E> b){
//
//	}
}