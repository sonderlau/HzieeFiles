package com.hziee.manage.sys;

import com.hziee.manage.sys.utils.SHA1;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


import javax.annotation.Resource;

@SpringBootTest
class SysApplicationTests {

    @Resource
    SHA1 sha1;


    @Test
    void contextLoads() {
        System.out.println(sha1.encrypt("111"));

    }

}
