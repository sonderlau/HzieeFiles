package com.hziee.manage.sys.conrtroller;

import com.hziee.manage.sys.dao.ProjectDao;
import com.hziee.manage.sys.entities.ProjectEntity;
import com.hziee.manage.sys.entities.ProjectUsersEntity;
import com.hziee.manage.sys.entities.RequirementsEntity;
import com.hziee.manage.sys.service.ProjectService;
import com.hziee.manage.sys.utils.R;
import com.hziee.manage.sys.utils.SHA1;

import com.hziee.manage.sys.vo.*;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@RequestMapping("/product")
@RestController
public class ProjectController {


    @Resource
    ProjectService projectService;

    @Resource
    ProjectDao projectDao;


    @Resource
    SHA1 sha1;



    @GetMapping("/getU")
    public R getu(@RequestParam("project_id")Integer project_id){
        List<ProjectUsersEntity> entity = projectDao.findPU(project_id);
        List<Integer> collect = entity.stream().map(ProjectUsersEntity::getUser_id).collect(Collectors.toList());
        return R.ok().put("data",collect);
    }

    /**
     * 增加用户对应项目
     */
    @PostMapping("/addu")
    public R addUsers(@RequestBody UsesCo usesCo){
        usesCo.getUser_id().stream().forEach(ussCo->{
            projectDao.inseryPU(ussCo,usesCo.getProject_id());
        });
        return R.ok();
    }

    /**
     * 新增需求
     */
    @PostMapping("/addR")
    public R addR(@RequestBody RVo rVo){
        VersionIdVo versionIdVo = new VersionIdVo();
        versionIdVo.setUpdatedTime(new Date());
        versionIdVo.setCurrentVersion("version");
        String string = versionIdVo.toString();
        String encrypt = sha1.encrypt(string);
        projectDao.insertR(encrypt,rVo.getName(),new Date());
        RequirementsEntity entity = projectDao.findByRV(encrypt);
        projectDao.updateProject(rVo.getProject_id(),entity.getRequirement_id());
        projectDao.insertPR(rVo.getProject_id(), entity.getRequirement_id());
        projectDao.addVersion(encrypt, entity.getRequirement_id());
        return R.ok();
    }

    /**
     * 新增项目
     */
    @PostMapping("/addProject")
    public R addProject(@RequestBody ProjectEntity projectEntity){
        ProjectEntity projectEntity1 = new ProjectEntity();
        BeanUtils.copyProperties(projectEntity,projectEntity1);
        projectDao.insertproject(projectEntity1);
        return R.ok().put("data",projectEntity1.getProject_id());
    }

    /**
     * 获取当前用户可以进行查看的项目列表
     */
    @GetMapping("/{userId}/product/list")
    public R projectList(@PathVariable("userId") Integer userId) {
        ProductListVo vos = projectService.productList(userId);
        return R.ok().put("data", vos);
    }

    /**
     * 查看某项目的所有需求
     */
    @GetMapping("/projectRequirements/{projectId}")
    public R projectRequirements(@PathVariable("projectId") Integer projectId) {
        List<RequirementsEntity> requirementsEntities = projectService.projectRequirements(projectId);
        return R.ok().put("data", requirementsEntities);
    }

    /**
     * 删除一个需求或项目
     */
    @DeleteMapping("/delete/{type}")
    public R deleteProjectOrRequirement(@PathVariable("type") String type,
                                        @RequestParam("value") Integer value,
                                        @RequestParam("userId") Integer userId) {
        int requirement = projectService.deleteProjectOrRequirement(type, value, userId);
        if (requirement == 1){
            return R.ok();
        }else {
            return R.error("没有权限");
        }
    }

    /**
     * 获取某一需求的所有版本
     */
    @GetMapping("/getAll/{requirementId}")
    public R allRequirementVersions(@PathVariable("requirementId") Integer requirementId){
        VersionsVo versionsVo = projectService.getAllRequirementVersions(requirementId);
        return R.ok().put("data",versionsVo);
    }

    /**
     * 将某一个需求回滚到指定的版本
     */
    @GetMapping("/Old")
    public R getOldVersion(@RequestParam("requirementId") Integer requirementId,
                           @RequestParam("versionId") String versionId){
        projectService.getOldVersion(requirementId,versionId);
        return R.ok();
    }

    /**
     * 查看某一需求的指定版本的全部具体内容
     */
    @GetMapping("/get/aLLVersionRequirements")
    public R getALLVersionRequirements(@RequestParam("requirementId") Integer requirementId,
                                       @RequestParam("versionId") String versionId){
        RequirementsVo requirementsVo = projectService.getALLVersionRequirements(requirementId,versionId);
        return R.ok().put("data",requirementsVo);
    }

    /**
     * 对当前的需求进行更新
     */
    @PutMapping("/update")
    public R updateRequirement(@RequestBody RequirementUpdateVo requirementUpdateVo){
        int r = projectService.updateRequirement(requirementUpdateVo);
        if (r==1){
            return R.ok();
        }else {
            return R.error("更新失败");
        }
    }
}
