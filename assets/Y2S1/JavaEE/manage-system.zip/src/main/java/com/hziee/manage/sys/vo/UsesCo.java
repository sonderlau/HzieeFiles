package com.hziee.manage.sys.vo;

import lombok.Data;

import java.util.List;

@Data
public class UsesCo {
    private Integer project_id;
    private List<Integer> user_id;
}
