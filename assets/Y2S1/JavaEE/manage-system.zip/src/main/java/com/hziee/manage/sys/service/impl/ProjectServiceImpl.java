package com.hziee.manage.sys.service.impl;

import com.hziee.manage.sys.dao.ProjectDao;
import com.hziee.manage.sys.entities.*;
import com.hziee.manage.sys.service.ProjectService;
import com.hziee.manage.sys.utils.SHA1;
import com.hziee.manage.sys.vo.*;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class ProjectServiceImpl implements ProjectService {

    @Resource
    private ProjectDao projectDao;

    @Resource
    private SHA1 sha1;

    /**
     * 查询用户拥有的项目
     * @param userId
     * @return
     */
    @Override
    public List<ProjectEntity> findByOwnerId(Integer userId) {
        return projectDao.findByOwnerId(userId);
    }

    @Override
    public ProductListVo productList(Integer userId) {
        List<ProjectEntity> productEntities = this.findByOwnerId(userId);
        ProductListVo productListVo = new ProductListVo();
        List<ProductListVo.Product> collect = productEntities.stream().map(projectEntity -> {
            ProductListVo.Product owed = new ProductListVo.Product();
            UserEntity userEntity = projectDao.findOwnerNameById(projectEntity.getOwner_id());
            List<ProjectRequirementsEntity> amount = this.findRequirementsByProductId(projectEntity.getProject_id());
            owed.setName(projectEntity.getName());
            owed.setOwnerName(userEntity.getUsername());
            owed.setProductId(projectEntity.getProject_id());
            owed.setRequirementAmount(amount.size());
            return owed;
        }).collect(Collectors.toList());
        List<ProjectUsersEntity> projectUsersEntities = projectDao.findByUserId(userId);
        List<ProductListVo.Product> collect1 = projectUsersEntities.stream().map(item -> {
            ProductListVo.Product visible = new ProductListVo.Product();
            ProjectEntity projectEntity = projectDao.findByProjectId(item.getProject_id());
            List<ProjectRequirementsEntity> requirementsByProductId = this.findRequirementsByProductId(projectEntity.getProject_id());
            UserEntity ownerNameById = projectDao.findOwnerNameById(projectEntity.getOwner_id());
            visible.setRequirementAmount(requirementsByProductId.size());
            visible.setProductId(item.getProject_id());
            visible.setOwnerName(ownerNameById.getUsername());
            visible.setName(projectEntity.getName());
            return visible;
        }).collect(Collectors.toList());
        productListVo.setOwned(collect);
        productListVo.setVisible(collect1);
        return productListVo;
    }

    @Override
    public List<ProjectRequirementsEntity> findRequirementsByProductId(Integer project_id) {
        return projectDao.findAmount(project_id);
    }

    /**
     * 查看某项目的所有需求
     * @param projectId
     * @return
     */
    @Override
    public List<RequirementsEntity> projectRequirements(Integer projectId) {
        List<ProjectRequirementsEntity> projectRequirementsEntities = projectDao.findPRByprojectId(projectId);
        List<RequirementsEntity> collect = projectRequirementsEntities.stream().map(projectRequirementsEntity -> {
            RequirementsEntity requirementsEntity = projectDao.findRequirements(projectRequirementsEntity.getRequirement_id());
            return requirementsEntity;
        }).collect(Collectors.toList());
        return collect;
    }

    @Override
    public int deleteProjectOrRequirement(String type, Integer value, Integer userId) {
        //删除需求
        if ("Requirement".equalsIgnoreCase(type)){
            ProjectRequirementsEntity requirementsEntity = projectDao.findPRByRequirementId(value);
            ProjectEntity projectEntity = projectDao.findByProjectId(requirementsEntity.getProject_id());
            //是否为这个项目的拥有者
            if (projectEntity.getOwner_id().equals(userId)){
                //拥有者删除需求，并且删除关联表内容
                projectDao.deleteProjectRequirementsBy(projectEntity.getProject_id());
                // projectDao.deleteRequirementsBy(value);
                return 1;
            }else {
                return 0;
            }
        }else {
            //删除项目
            ProjectEntity projectEntity = projectDao.findByProjectId(value);
            if (projectEntity.getOwner_id().equals(userId)){
                projectDao.deleteProjectById(value);
                projectDao.deleteProjectRequirementsBy(value);
                return 1;
            }else {
                return 0;
            }
        }
    }

    @Override
    public VersionsVo getAllRequirementVersions(Integer requirementId) {
        RequirementsEntity requirementsEntity = projectDao.findVersionById(requirementId);
        VersionsVo versionsVo = new VersionsVo();
        versionsVo.setCurrent(requirementsEntity.getVersion_id());
        List<VersionEntity> versionEntities = projectDao.findPastVersionById(requirementId);
        List<VersionsVo.History> collect = versionEntities.stream().map(versionEntity -> {
            VersionsVo.History history = new VersionsVo.History();
            if (!versionEntity.equals(requirementsEntity.getVersion_id())) {
                history.setVersion(versionEntity.getVersion_id());
            }
            return history;
        }).collect(Collectors.toList());
        versionsVo.setHistory(collect);
        return versionsVo;
    }

    @Override
    public void getOldVersion(Integer requirementId, String versionId) {
        RequirementsEntity requirements = projectDao.findRequirements(requirementId);
        requirements.setVersion_id(versionId);
        requirements.setUpdated_time(new Date());
        projectDao.updateRequirement(requirements.getRequirement_id(),requirements.getVersion_id(),requirements.getUpdated_time());
    }

    @Override
    public RequirementsVo getALLVersionRequirements(Integer requirementId, String versionId) {
        RequirementsEntity requirementsEntity = projectDao.findRequirements(requirementId);
        RequirementsVo requirementsVo = new RequirementsVo();
        BeanUtils.copyProperties(requirementsEntity,requirementsVo);
        VersionEntity versionEntity = projectDao.findVersion(versionId);
        RequirementsVo.Versions versions = new RequirementsVo.Versions();
        BeanUtils.copyProperties(versionEntity,versions);
        List<VersionAttachmentsEntity> versionAttachmentsEntities = projectDao.findVAById(versionId);
        List<RequirementsVo.Attachments> collect = versionAttachmentsEntities.stream().map(versionAttachmentsEntity -> {
            RequirementsVo.Attachments attachments = new RequirementsVo.Attachments();
            AttachmentsEntity attachmentsEntity = projectDao.findABy(versionAttachmentsEntity.getAttachments_id());
            BeanUtils.copyProperties(attachmentsEntity, attachments);
            return attachments;
        }).collect(Collectors.toList());
        requirementsVo.setAttachments(collect);
        requirementsVo.setVersion(versions);
        return requirementsVo;
    }

    @Override
    public int updateRequirement(RequirementUpdateVo requirementUpdateVo) {
        /*
         * 判断 `Attachments` 数组长度是否为 `0`  `details`字段是否为空
         *
         * 1. 若两者都满足 则结束当前所有的操作
         * 2. 若至少一者满足
         *    1. 生成新的`VersionId` ^[1]^
         * > 2. 上述的`Object`转成`String`类型并进行`SHA-1`加密后
         *    2. 判断 `details` 字段是否为 `""` 空
         *       1. 若为空 则将新的 `VersoinId` 的字段中的 `details` 设置为旧 `VersoinId` 对应的 `details` 内容
         *       2. 若不为空  则将新的 `VersoinId` 的字段中的 `details` 设置为传过来的`details`内的内容
         *    3. 判断 `Attachments` 数组长度是否为 `0`
         *       1. 若为 `0`
         *          1. 获取旧`VersionId` 在 `VersionAttachments`表中对应的所有`AttachmentsId`字段的值
         *          2. 在`VersoinAttachments` 表中插入 新`VersoinId` 以及所有的上一步获得的旧`AttachmentsId`的值
         *       2. 若不为`0`
         *          1. 在`VersionAttachments`表中插入 新`VersionId`以及传过来的`Attachments`数组内的内容
         */
        //1. 判断 `Attachments` 数组长度是否为 `0`  `details`字段是否为空,若两者都满足 则结束当前所有的操作
        if (requirementUpdateVo.getAttachments().size()==0&& Objects.equals(requirementUpdateVo.getDetails(), "")){
            return 0;
        }else {
            VersionIdVo versionIdVo = new VersionIdVo();
            versionIdVo.setUpdatedTime(new Date());
            versionIdVo.setCurrentVersion(projectDao.findVersionById(requirementUpdateVo.getRequirement_id()).getVersion_id());
            String string = versionIdVo.toString();
            //* 新生成得版本号
            String versionId = sha1.encrypt(string);
            //* 当前得需求
            RequirementsEntity entity = projectDao.findRequirements(requirementUpdateVo.getRequirement_id());
            String oldV = entity.getVersion_id();
            VersionEntity oldVersion = projectDao.findVersion(oldV);
            entity.setVersion_id(versionId);
            //2. 判断 `details` 字段是否为 `""` 空
            //1. 若为空 则将新的 `VersoinId` 的字段中的 `details` 设置为旧 `VersoinId` 对应的 `details` 内容
            if (requirementUpdateVo.getDetails().equals("")){
                //更新需求表的versionId
                projectDao.updateRequirement(entity.getRequirement_id(),versionId,new Date());
                projectDao.insertVersion(versionId,oldVersion.getDetails(),requirementUpdateVo.getRequirement_id());
            }else {
                //2. 若不为空  则将新的 `VersoinId` 的字段中的 `details` 设置为传过来的`details`内的内容
                projectDao.insertVersion(versionId,requirementUpdateVo.getDetails(),requirementUpdateVo.getRequirement_id());
                projectDao.updateRequirement(entity.getRequirement_id(),versionId,new Date());
            }
            //3. 判断 `Attachments` 数组长度是否为 `0`
            if (requirementUpdateVo.getAttachments().size()==0){
                //1. 若为 `0`
                //  1. 获取旧`VersionId` 在 `VersionAttachments`表中对应的所有`AttachmentsId`字段的值
                //  2. 在`VersoinAttachments` 表中插入 新`VersoinId` 以及所有的上一步获得的旧`AttachmentsId`的值
                List<VersionAttachmentsEntity> versionAttachmentsEntities = projectDao.findVAById(oldV);
                versionAttachmentsEntities.stream().forEach(item->{
                    projectDao.insertVA(versionId,item.getAttachments_id());
                });
            }else {
                //  2. 若不为`0`
                //      1. 在`VersionAttachments`表中插入 新`VersionId`以及传过来的`Attachments`数组内的内容
                List<RequirementsVo.Attachments> attachments = requirementUpdateVo.getAttachments();
                attachments.stream().forEach(attachments1 -> {
                    AttachmentsEntity attachmentsEntity = new AttachmentsEntity();
                    BeanUtils.copyProperties(attachments1,attachmentsEntity);
                    projectDao.insertAA(attachmentsEntity);
                    projectDao.insertVA(versionId,attachmentsEntity.getAttachments_id());
                });
            }
            return 1;
        }
    }

}
