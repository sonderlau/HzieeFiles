package com.hziee.manage.sys.entities;

import lombok.Data;

@Data
public class ProjectRequirementsEntity {

    private Integer project_id;

    private Integer requirement_id;
}
