package com.hziee.manage.sys.entities;

import lombok.Data;

@Data
public class UserEntity {
    private Integer user_id;
    private String username;
    private String password;
}
