package com.hziee.manage.sys.entities;

import lombok.Data;

@Data
public class AttachmentsEntity {
    private Integer attachments_id;
    private String src;
    private String type;
    private String md5;
}
