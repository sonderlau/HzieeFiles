package com.hziee.manage.sys.entities;

import lombok.Data;

@Data
public class VersionAttachmentsEntity {
    private String version_id;
    private Integer attachments_id;
}
