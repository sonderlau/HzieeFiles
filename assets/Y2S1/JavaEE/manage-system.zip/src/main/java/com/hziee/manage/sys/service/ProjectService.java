package com.hziee.manage.sys.service;

import com.hziee.manage.sys.entities.ProjectEntity;
import com.hziee.manage.sys.entities.ProjectRequirementsEntity;
import com.hziee.manage.sys.entities.RequirementsEntity;
import com.hziee.manage.sys.vo.ProductListVo;
import com.hziee.manage.sys.vo.RequirementUpdateVo;
import com.hziee.manage.sys.vo.RequirementsVo;
import com.hziee.manage.sys.vo.VersionsVo;

import java.util.List;

public interface ProjectService {

    List<ProjectEntity> findByOwnerId(Integer userId);

    ProductListVo productList(Integer userId);

    List<ProjectRequirementsEntity> findRequirementsByProductId(Integer project_id);

    List<RequirementsEntity> projectRequirements(Integer projectId);

    int deleteProjectOrRequirement(String type, Integer value, Integer userId);

    VersionsVo getAllRequirementVersions(Integer requirementId);

    void getOldVersion(Integer requirementId, String versionId);

    RequirementsVo getALLVersionRequirements(Integer requirementId, String versionId);

    int updateRequirement(RequirementUpdateVo requirementUpdateVo);
}
