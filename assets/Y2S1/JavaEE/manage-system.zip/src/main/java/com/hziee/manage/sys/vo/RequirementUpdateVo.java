package com.hziee.manage.sys.vo;

import lombok.Data;

import java.util.List;

@Data
public class RequirementUpdateVo {

    private Integer requirement_id;
    private String details;
    private List<RequirementsVo.Attachments> attachments;
}
