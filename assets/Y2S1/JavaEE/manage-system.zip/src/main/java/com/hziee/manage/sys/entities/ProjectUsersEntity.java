package com.hziee.manage.sys.entities;

import lombok.Data;

@Data
public class ProjectUsersEntity {
    private Integer project_id;
    private Integer user_id;
}
