package com.hziee.manage.sys.vo;

import lombok.Data;

@Data
public class RVo {
    private String name;
    private Integer project_id;
}
