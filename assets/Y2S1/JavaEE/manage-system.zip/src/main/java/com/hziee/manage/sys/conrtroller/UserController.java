package com.hziee.manage.sys.conrtroller;

import com.hziee.manage.sys.entities.UserEntity;
import com.hziee.manage.sys.service.UserService;
import com.hziee.manage.sys.utils.R;
import com.hziee.manage.sys.vo.UserLoginVo;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.logging.Logger;

@RestController
@RequestMapping("/users")
public class UserController {

    @Resource
    UserService userService;

        /**
         * 登入
         */
        @PostMapping("/login")
        public R login(@RequestBody UserLoginVo userEntity){
            UserEntity login = userService.login(userEntity);
            return R.ok().put("user",login);
        }
}
