
module.exports = {
  devServer: {
    proxy: {
      '/product': {
        target: 'http://localhost:8002',
        changeOrigin: true,
        pathRewrite: {
          '^/product': '/product'
        }
      },
      '/member': {
        target: 'http://localhost:8001',
        changeOrigin: true,
        pathRewrite: {
          '^/member': '/member'
        }
      },
      '/users/': {
        target: 'http://localhost:8003',
        changeOrigin: true,
        pathRewrite: {
          '^/users': '/users'
        }
      }
    },
    disableHostCheck: true
  },
  chainWebpack: config => {
    // 发布模式
    config.when(process.env.NODE_ENV === 'production', config => {
      config
        .entry('app')
        .clear()
        .add('./src/main-prod.js')

      config.set('externals', {
        vue: 'Vue',
        'vue-router': 'VueRouter',
        axios: 'axios',
        lodash: '_',
        echarts: 'echarts',
        nprogress: 'NProgress',
        'vue-quill-editor': 'VueQuillEditor'
      })

      config.plugin('html').tap(args => {
        args[0].isProd = true
        return args
      })
    })

    // 开发模式
    config.when(process.env.NODE_ENV === 'development', config => {
      config
        .entry('app')
        .clear()
        .add('./src/main-dev.js')

      config.plugin('html').tap(args => {
        args[0].isProd = false
        return args
      })
    })
  }
}
