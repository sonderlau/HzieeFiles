import service from './index'

/**
 * 获取拼团信息
 * @param mId
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getGroupings (mId) {
  return service.get('/users/group/grouping/get', {
    params: {
      m_id: mId
    }
  })
}

/**
 * 获取拼团的用户列表
 * @param gId
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getGroupingUsers (gId) {
  return service.get('/users/groupuser/group/users', {
    params: {
      g_id: gId
    }
  })
}
