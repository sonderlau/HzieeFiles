import axios from 'axios'
// import { prefix, usersPort } from '@/utils/request'

const service = axios.create({
  baseURL: ''

})

export default service
