import service from './index'

/**
 * 登录接口
 * @param username
 * @param password
 * @returns {Promise<AxiosResponse<any>>}
 */
export function login (username, password) {
  return service.post('/product/merchant/merchant/login', {
    username,
    password
  })
}

// eslint-disable-next-line camelcase
export function updateInfo ({ m_id, username, password, name, longitutde, latitude }) {
  return service.patch('/product/merchant/update1', {
    mid: m_id,
    username,
    password,
    name,
    longitutde,
    latitude
  })
}
