import service from './index'

/**
 * 获取当前的入库信息
 * @param mId
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getStorage (mId) {
  return service.get('/product/commodities/merchant/products/use', {
    params: {
      m_id: mId
    }
  })
}

/**
 * 获取到所有的可存入的商品
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getAllGoods () {
  return service.get('/product/merchant/commodities/get')
}

/**
 * 入库商品
 * @param cId
 * @param mId
 * @param inboundDate
 * @param shelfLife
 * @returns {Promise<AxiosResponse<any>>}
 */
export function inbound (cId, mId, inboundDate, shelfLife) {
  return service.post('/product/commodities/merchant/inbound', {
    cid: cId,
    mid: mId,
    inboundDate: inboundDate,
    shelfLife: shelfLife
  })
}

/**
 * 更新入库信息
 * @param mId
 * @param m_id
 * @param amount
 * @returns {Promise<AxiosResponse<any>>}
 */
// eslint-disable-next-line camelcase
export function updateInbound (m_id, { c_id, amount, inbound_date, shelf_life }) {
  return service.post('/product/commodities/inbound/update', {
    mid: m_id,
    cid: c_id,
    amount,
    // eslint-disable-next-line camelcase
    inboundDate: inbound_date,
    shelfLife: shelf_life
  })
}
