import service from './index'

/**
 * 查询商家的订单
 * @param mId
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getOrders (mId) {
  return service.get('/product/merchant/merchant/orders', {
    params: {
      m_id: mId
    }
  })
}

/**
 * 更改订单状态
 * @param mId
 * @param oId
 * @param status
 * @returns {Promise<AxiosResponse<any>>}
 */
export function changeStatus (mId, oId, status) {
  return service.get('/product/orders/status/change', {
    params: {
      m_id: mId,
      o_id: oId,
      status
    }
  })
}
