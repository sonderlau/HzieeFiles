import axios from 'axios'
import { prefix, memberPort } from '@/utils/request'

const service = axios.create({
  baseURL: prefix + memberPort
})

export default service
