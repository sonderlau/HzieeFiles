import axios from 'axios'

const prefix = 'http://localhost'

const productPort = '/product/'
const memberPort = '/member/'
const usersPort = '/users/'

export default axios
export {
  productPort,
  memberPort,
  usersPort,
  prefix
}
