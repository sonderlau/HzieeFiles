<template>
  <div>

    <el-table border stripe :data="list">
      <el-table-column prop="c_id" label="#"></el-table-column>
      <el-table-column prop="name" label="名称"></el-table-column>
      <el-table-column prop="value" label="价格"></el-table-column>
      <el-table-column label="属性">
        <template  v-if="scope.row.specification.property.length !== 0"  slot-scope="scope">
          <el-tag v-for="(item,index) in scope.row.specification.property"
                  :key="index" effect="dark" type="success">{{item.name}} :{{item.action.delta === 'add' ? '+': '-'}} ¥{{item.action.value}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="口味">
        <template  v-if="scope.row.specification.taste.length !== 0"  slot-scope="scope">
          <el-tag v-for="(item,index) in scope.row.specification.taste"
                  :key="index" effect="dark" type="success">{{item.name}} : ¥{{item.value}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="success" size="mini" @click="Inbound(scope.row)">入库</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="入库日期" :visible.sync="inboundFormVisible">
      <el-form
        :model="inboundForm"
        label-width="100px">
        <el-form-item label="名称">
          <el-input disabled v-model="inboundForm.name"></el-input>
        </el-form-item>
        <el-form-item label="保质期(天)">
          <el-input-number v-model="inboundForm.shelf_life"
                           :min="1" :max="900" >

          </el-input-number>
        </el-form-item>
        <el-form-item label="数量">
          <el-input-number v-model="inboundForm.amount"
                           :min="1" :max="10" label="数量">

          </el-input-number>
        </el-form-item>
        <el-form-item label="入库日期">
          <el-date-picker
            v-model="inboundForm.deadline"
            type="datetime"
            placeholder="选择日期时间">
          </el-date-picker>
        </el-form-item>

      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="inboundFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="update">确 定</el-button>
      </span>

    </el-dialog>
  </div>
</template>

<script>
import { getAllGoods, inbound } from '@/api/product/storage'

export default {
  name: 'PartDetail',
  data () {
    return {
      list: [],
      inboundForm: {
        amount: 1
      },
      inboundFormVisible: false
    }
  },
  created () {
    this.updateList()
  },
  methods: {
    updateList () {
      getAllGoods()
        .then((res) => {
          this.list = res.data.data
        })
    },
    Inbound (row) {
      this.inboundFormVisible = true
      this.inboundForm = row
    },
    //* 入库商品
    update () {
      inbound(this.inboundForm.c_id,
        JSON.parse(window.sessionStorage.getItem('token')).data.mid,
        this.getExactTime(this.inboundForm.deadline),
        this.inboundForm.shelf_life)
        .then(() => {
          this.$message.success('入库成功')
          this.inboundFormVisible = false
        })
        .catch(() => {
          this.$message.error('入库失败')
        })
    },
    getExactTime (date) {
      const year = date.getFullYear() + '-'
      const month = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-'
      const dates = date.getDate() + ' '
      const hour = date.getHours() + ':'
      const min = date.getMinutes() + ':'
      const second = date.getSeconds()
      return year + month + dates + hour + min + second
    }

  }
}
</script>

<style scoped>

</style>
