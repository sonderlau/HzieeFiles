<template>
<div>
  <el-table stripe :data="list">
    <el-table-column prop="o_id" label="#"></el-table-column>
    <el-table-column prop="orderedTime" label="订单时间"></el-table-column>
    <el-table-column label="价格">
      <template  slot-scope="scope">
        ¥ {{scope.row.details.amount * scope.row.details.value}}
      </template>
    </el-table-column>
    <el-table-column label="图片">
      <img style="height: 10rem;" slot-scope="scope" :src="scope.row.details.image" alt="infraction image">
    </el-table-column>
    <el-table-column label="当前状态">
      <template slot-scope="scope">
        <el-tag type="warning">{{scope.row.status.name}}</el-tag>
      </template>

    </el-table-column>
    <el-table-column label="更改状态">
      <template slot-scope="scope">
        <el-button type="success" size="mini" @click="status(scope.row)">更改状态</el-button>
      </template>

    </el-table-column>
  </el-table>
</div>
</template>

<script>
import { getOrders, changeStatus } from '@/api/product/orders'

export default {
  name: 'Order',
  data () {
    return {
      list: []
    }
  },
  created () {
    //* 获取订单信息
    this.getOrders()
  },
  methods: {
    getOrders () {
      getOrders(JSON.parse(window.sessionStorage.getItem('token')).data.mid)
        .then((res) => {
          this.list = res.data.data
        })
    },
    status (row) {
      //* 更改订单状态
      changeStatus(JSON.parse(window.sessionStorage.getItem('token')).data.mid,
        row.o_id,
        row.status.next)
        .then(() => {
          this.$message.success('更改成功')
          this.getOrders()
        })
        .catch(() => {
          this.$message.error('更改失败')
        })
    }
  }
}
</script>

<style scoped>

</style>
