// pages/grouping/grouping.js
import {getGroupings, joinGrouping} from '../../apis/users/grouping'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  grab: function(res) {
    console.log(res);
    let info = res.detail;
    // todo: 发送抢购信息
    joinGrouping(wx.getStorageSync('openId'),info.g_id)
    .then( (res) => {
      console.log(res)
      if (res.data.code === 0) {
        wx.showToast({
          title: res.data.msg,
          duration: 2000
        })
  
        setTimeout(() => {
          wx.navigateBack({
            delta: 1,
          })
        }, 2100);
      }else{
        wx.showToast({
          title: res.data.msg,
          icon: 'none'
        })
      }
      
      
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.update()
  },

  update: function(){
    //* 获取所有的拼团信息
    getGroupings()
    .then(res => {
      //todo 对所有的拼团时间做更改
      let groupings = res.data.data;
      groupings.forEach(element => {
        element.deadline = parseInt((new Date(element.deadline).getTime() - new Date().getTime()) / 1000)
      })
      this.setData({
        groupings
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})