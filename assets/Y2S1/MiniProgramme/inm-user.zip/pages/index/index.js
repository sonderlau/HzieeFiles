import {activateCoupon} from '../../apis/users/coupon'
Page({
  data: {
  },
  onLoad: function () {
    this.setData({
      //* 轮播图
      swiper_items: [
        {src: "https://hzieecos-1300064754.cos.ap-shanghai.myqcloud.com/inm/band/1.jpg"},
        {src:"https://hzieecos-1300064754.cos.ap-shanghai.myqcloud.com/inm/band/2.jpg"}
      ]
    })
    
  },

  //* 扫描二维码
  scan: function(){
    wx.scanCode({
      onlyFromCamera: true,
      scanType: 'qrCode',
      success(res) {
        //* 确认类型
        if(res.scanType === 'QR_CODE'){

          let cdkey = res.result
          console.log(cdkey);
          activateCoupon(wx.getStorageSync('openId'),cdkey)
          .then(()=>{
            wx.showToast({
              title:"成功",
              icon: 'success',
              duration: 1800
            })
          })
          .catch((res)=>{
            console.warn(res);
            wx.showToast({
              title:"错误"+res,
              duration: 1900
            })
          })
        }
      }
    })
  },
  // 跳转到优惠券激活
  navigateCoupons: function() {
    wx.navigateTo({
      url: '../coupons/coupons',
    })
  },
  // 跳转到选择商家界面
  buy: function(res) {
    wx.navigateTo({
      url: '../buy/merchants/merchants?type='+res.currentTarget.dataset.type,
    })
  },
  grouping: function() {
    wx.navigateTo({
      url: '../grouping/grouping',
    })
  }
})
