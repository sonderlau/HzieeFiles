// pages/PersonalInfo_details/points/points.js
const onfire = require('../../../utils/onfire')
import {getItems,redeemItem,getPoints} from '../../../apis/member/points'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    point_value: 0,
    items:[
      {
        item_id: "1",
        cost: 20,
        name: "啊a",
        image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1607952930448&di=72fb8864778d4bbc6468335b257cfc7b&imgtype=0&src=http%3A%2F%2Ffile15.zk71.com%2FFile%2FCorpEditInsertImages%2F2016%2F08%2F08%2F0_meishi_0060_20160808175656.jpg"
      },{
        item_id: "444",
        cost: 20,
        name: "啊a",
        image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1607952930448&di=72fb8864778d4bbc6468335b257cfc7b&imgtype=0&src=http%3A%2F%2Ffile15.zk71.com%2FFile%2FCorpEditInsertImages%2F2016%2F08%2F08%2F0_meishi_0060_20160808175656.jpg"
      },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //* 获取所有可兑换的商品
    let that = this;
    getItems().then(res => {
      console.log(res);
      that.setData({
        items: res.data.data
      })
      wx.lin.renderWaterFlow(res.data.data, false, ()=>{
        console.log("water flow~~");
      })
    })

    onfire.on("redeem",(res)=> {
      console.log(res);
      let item_id = res.currentTarget.dataset.itemId;
      redeemItem(wx.getStorageSync('openId'),item_id)
      .then( ()=>{
        //* 返回到上一层
        wx.navigateBack()
      })
      .catch(res => {
        wx.showToast({
          title: "兑换失败"+res,
          duration: 2000
    
        })
      })
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //* 获取积分
    let that = this;
    getPoints(wx.getStorageSync('openId'))
    .then(res => {
      console.log(res);
      let value = res.data.data === null ? 0 : res.data.data
      that.setData({
        point_value: value
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})