// pages/PersonalInfo_details/vip/recharge/recharge.js
import {getAllVips,rechargeVip} from '../../../../apis/member/vip'
import { member_port } from '../../../../utils/request';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    active: 0,
    number: 1,
    vips: [
      {
        v_id: "11",
        cost: 10,
        name: "大会员"
      },
      {
        v_id: "11",
        cost: 10,
        name: "大会员"
      },
      {
        v_id: "11",
        cost: 10,
        name: "大会员"
      }
    ]
  },
  //* 点击按钮
  click: function(res) {
    console.log(res);
    this.setData({
      active: res.currentTarget.dataset.index,
      recharge: res.currentTarget.dataset.info
    })
  },


  // * 改变月数
  numberChange: function(res) {
    this.setData({
      number: res.detail.count
    })
  },

  // * 重置
  recharge: function() {
    //* 为当前账户充值
    console.log(this.data.recharge);
    //todo 充值当前账号
    rechargeVip(wx.getStorageSync('openId'),this.data.recharge.vid,this.data.number)
    .then((res) => {
      console.log(res);
      wx.navigateBack({
        delta: 2
      })
    })
    .catch( res => {
      console.error(res);
      wx.showToast({
        title: '失败',
        icon: 'error',
        duration: 1500
      })
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //* 获取可充值的会员信息
    let that = this;
    getAllVips()
    .then(res => {
      //todo 赋值到数据 vips
      console.log(res);
      that.setData({
        vips: res.data.data,
        recharge: res.data.data[0]
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})