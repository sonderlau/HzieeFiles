// pages/buy/pay/pay.js
import {buyItems} from '../../../apis/product/buy'
import {getCoupons} from '../../../apis/users/coupon'
import EE from '../../../utils/onfire'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    coupons: [
      {
          coupon_key: "cdkeyhere",
          value: 100,
          deadline: "2020-12-10 11:43:11.000000",
      }
  ]
  },

  coupon: function (res) {

    if (res.detail.checked){
      console.log(res);
      //* 勾选了优惠券
      this.upData({
        coupon_key: res.detail.cell.couponKey,
        data: {
          price_coped:Number(this.data.data.price) - Number(res.detail.cell.value)
        }
      })
    }else {
      this.upData({
        coupon_key: '',
        data: {
          price_coped: this.data.data.price
        }
      })
    }
  },

  confirm: function(res) {

    buyItems(this.data.data.m_id,
            wx.getStorageSync('openId'),
            this.data.data.commodities, 
            this.data.data.type,
            this.data.coupon_key ? this.data.coupon_key : "" ,
            this.data.data.price_coped)
    .then(()=> {
      wx.navigateBack({
        delta:2
      })
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    this.setData({
      data:wx.getStorageSync('pay')
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // todo 获取到优惠券
    getCoupons(wx.getStorageSync('openId'))
    .then(res => {
      let coupons = []
      //* 对优惠券的限制 做处理
      let orderData = this.data.data
      console.log(orderData);
      console.log(res.data.data.available);
      res.data.data.available.forEach(element => {

        //* 当前优惠券有限制
        if(element.couponRulesEntities.length !== 0){
          if(element.couponRulesEntities.every(rules => {
            switch(rules.type){
              //? 检查商家
              case "merchant":
                if(Number(orderData.m_id) === Number(rules.value)){
                  coupons.push(element)
                  console.log("商家检查通过");
                }
                break;
              //? 检查订单价格
              case "value":
                if(Number(orderData.price) >= Number(rules.value)){
                  coupons.push(element)
                  console.log("价格检查通过");
                }
                break;
              //? 检查是否包含指定的商品
              case "commodity":
                if(orderData.commodities.some(good => {
                  return Number(good.c_id) === Number(rules.value)
                })){
                  coupons.push(element)
                }
              break;
            }
          })){
            coupons.push(element)
          }
        }else{
          //* 没有任何限制 可以直接使用
          coupons.push(element)
        }
      })
      this.setData({
        coupons
      })
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})