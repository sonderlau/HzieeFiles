// pages/buy/broswer/browser.js
import {getProducts} from '../../../apis/product/buy'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //* 购物车
    cart: [],
    price: 0.00,
    pay_available: true,
    popup_show: false,
    // 遮罩层的显示
    mask_show: false,
    // 遮罩层中 待选择的商品 
    mask_select: {},
    // 遮罩层中 待选商品的缓存
    mask_select_buffer: {
      amount: 0,
      //* 起始价格
      payment_orginal: 0.00,
      //* 增加口味之后的价格
      payment_taste: 0.00,
      //* 增加属性之后的价格
      payment_property: 0.00,
      //* 数量
      amount: 1,
      //* 最终的计算价格
      payment: 0.00
    }
    
  },

  //* 打开遮罩层
  openMask: function(res) {
    this.upData({
      mask_show: true,
      mask_select: res.currentTarget.dataset.item,
      mask_select_buffer: {
        payment_orginal: res.currentTarget.dataset.item.value,
        amount: 1,
        payment: 0
      }
    })
  },

  closeMask: function(){
    this.upData({
      mask_show: false
    })

    this.setData({
      //* 数据清空
      mask_select: {},
      mask_select_buffer: {}
    })
  },

  //* 选择口味
  maskTasteChange: function(res){
    console.log(res);
    this.upData({
      mask_select_buffer: {
        // 当前需要支付的金额
        payment_taste : res.detail.cell.value,
        // 口味名称
        specification: {
          taste: res.detail.cell.name
        }
      }
    })
  },

  //* 选择属性
  maskPropertyChange: function(res){
    console.log(res);
                    // 判断变化类型 + 变化值 + 变化之前的值
    let deltaValue = this.handelPropertyDelta(res.detail.cell.action.delta, res.detail.cell.action.value, this.data.mask_select_buffer.payment_taste );
    let amount = this.data.mask_select_buffer.amount === undefined ? 1 : this.data.mask_select_buffer.amount;
    console.log(amount);
    this.upData({
      mask_select_buffer: {
        payment_property:  deltaValue,
        // 需要支付的金额
        payment:  amount*deltaValue,
        specification: {
          property: res.detail.cell.name
        }
      }
    })
  },

  //* 商品数量
  maskNumberChange: function(res){
    this.upData({
      mask_select_buffer: {
        amount: res.detail.count,
        payment: this.data.mask_select_buffer.payment_property * res.detail.count
      }
    })
  },

  // * 加入购物车
  maskAddToCart: function(res) {
    //* 构建数据结构
    let data = {
      c_id: this.data.mask_select.c_id,
      amount: this.data.mask_select_buffer.amount,
      specification: this.data.mask_select_buffer.specification,
      value: this.data.mask_select_buffer.payment_property,
      name: this.data.mask_select.name,
      image: this.data.mask_select.image
    }

    let cart = this.data.cart;
    cart.unshift(data)
    
    this.upData({
      //* 添加价格
      price: this.data.price + this.data.mask_select_buffer.payment,
      //* 关闭遮罩
      mask_show: false,

    })
    this.setData({
      //* 数据清空
      mask_select: {},
      mask_select_buffer: {},
      //* 添加到开头
      cart
    })
  },

  //* 处理属性对价格的影响
  /**
   * 
   * @param {*} delta 变化类型
   * @param {*} value 变化值
   * @param {*} originValue 原价
   */
  handelPropertyDelta(delta,value, originValue){

    switch(delta){
      case "add":
        return Number(originValue) + Number(value);
      case "minus":
        return Number(originValue) - Number(value);
    }
  },


  //* 直接计数的处理

  handelDirectCount: function(res){

    if( res.detail.count < 0){
      console.log("直接不处理");
      return;
    }
    //* 对购物车中的商品查找 是否有已经存在的同种商品
    let cart = this.data.cart;
      //* 总价
    let price = this.data.price
    //* flag
    let flag = false
    cart.forEach(element => {
      if(element.c_id === res.currentTarget.dataset.item.c_id){
        //* 有相同的
          flag = true;
          // 对当前商品的数量进行更改
          element.amount = res.detail.count
          //* 购物车价格处理
          switch(res.detail.type){
            case "add":
              price = price + res.currentTarget.dataset.item.value
              break;
            case "reduce":
              price = price - res.currentTarget.dataset.item.value
              break;
          }
          this.setData({
            price,
            cart
          })
      }
    })

    //* 购物车中没有相同的商品
    if( !flag){
      // 构造数据结构
      let data = {
        c_id: res.currentTarget.dataset.item.c_id,
        name: res.currentTarget.dataset.item.name,
        image: res.currentTarget.dataset.item.image,
        value: res.currentTarget.dataset.item.value,
        amount: res.detail.count,
        specification: {
          taste: "",
          property: ""
        }
      }
      //* 加入购物车中
      cart.unshift(data)
      //* 价格
      price = price + (res.detail.count * res.currentTarget.dataset.item.value)
      this.setData({
        cart,
        price
      })
    }

    //* 改变显示的数量
    console.log("直接处理的赋值");
    this.upData({
      withoutOptionsObject:{
        [res.currentTarget.dataset.item.c_id]: res.detail.count
      }
    })

    
  },

   //* 页面超出界面处理
   directOut: function(res){
    console.warn("directOut")
   },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //* 获取到上个页面传过来的信息 即 m_id name type
    this.setData(JSON.parse(options.item))
    let that = this;
    getProducts(JSON.parse(options.item).m_id)
    .then(res => {
      //! 对没有属性和口味的商品生成一个存储数量的Object
      let withoutOptionsObject = {}
       //? 分类的循环
      res.data.data.forEach(element => {
          //? 分类下的商品循环
          element.items.forEach(inside_element => {
            //* 不具有属性和口味
            if( inside_element.specification.taste.length === 0 && inside_element.specification.property.length === 0){
              withoutOptionsObject[inside_element.c_id] = 0
            }
          })

      })
      console.log(res.data.data);
      that.setData({
        //* 获取到商品信息
        products: res.data.data,
        //* 不具有属性的商品Map
        withoutOptionsObject,
      })
    })

    
  },

  //* 切换选项卡
  changeTab: function(res){
    console.log(res);
    this.upData({
      currentProducts: 'card'+res.detail.activeKey
    })
  },


  //* 前往付款的界面
  pay: function() {
    let data = {
      m_id: this.data.m_id,
      openId: wx.getStorageSync('openId'),
      commodities: this.data.cart,
      price: this.data.price,
      price_coped: this.data.price,
      type: this.data.type
    }
    wx.setStorageSync('pay',data)
    wx.navigateTo({
      url: '../pay/pay',
    })
  },


  //* 打开底部的购物车
  openPopup: function(){
    this.setData({
      popup_show: !this.data.popup_show
    })
  },

  //* 改变购物车中物品的数量
  cartNumChange: function(res){
    if(res.detail.count === 0){
      return this.cartNumOut(res)
    }
    console.log(res);
    //* 找到购物车中的内容并更改
    let cart = this.data.cart;
    cart.forEach(element => {
      if (element.c_id === res.currentTarget.dataset.id){
        element.amount = res.detail.count
      }
    })
    console.log(cart);
    //* 找到主界面显示中的商品改变数量
    let withoutOptionsObject = this.data.withoutOptionsObject
    if (withoutOptionsObject[res.currentTarget.dataset.id]){
      withoutOptionsObject[res.currentTarget.dataset.id] = res.detail.count
    }
    //* 更改价格
    let price = this.data.price;
    switch(res.detail.type){
      case "add":
        price = price + res.currentTarget.dataset.value
        break;
      case "reduce":
        price = price - res.currentTarget.dataset.value
        break;
    }

    this.setData({
      cart,
      withoutOptionsObject,
      price
    })
  },

 

  //* 超出界限的数量
  cartNumOut: function(res){
    if (res.detail.way === "parameter"){
      return
    }
    console.warn("进行超界处理");
    console.log(res);
    //* 从购物车中删除该商品
    let cart = this.data.cart
    cart = cart.filter(element => {
      return element.c_id !== res.currentTarget.dataset.id
    })
    //* 找到主界面显示中的商品改变数量
    let withoutOptionsObject = this.data.withoutOptionsObject
    if (withoutOptionsObject[res.currentTarget.dataset.id]){
      withoutOptionsObject[res.currentTarget.dataset.id] = 0
    }
    //* 更改价格
    let price = this.data.price;
      //* 此时一般是更改数量为 0 的情况
    price = price - res.currentTarget.dataset.value
    this.setData({
      cart,
      price
    })
  },

  //* 购买页面
  buy: function(){
    //* 获取类型 - 购物车内的内容
  },

  //* 清空购物欸
  clearCart: function(){
    this.setData({
      cart: [],
      price: 0
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})