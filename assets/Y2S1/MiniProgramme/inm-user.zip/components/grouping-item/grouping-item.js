// components/grouping-item/grouping-item.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    info: {
      type: Object
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    demo: {
      g_id: "g_id here",
      name: "清仓大甩卖",
      merchant: {
          name: "店名",
          longitude: 48.1231231,
          latitude: 21.3169278
      },
      commodity:{
          name: "珍珠奶茶",
          value: 15,
          image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3214473833,849486410&fm=26&gp=0.jpg"
      },
      membership_max: 5,
      cost: 20,
      deadline: "6502"
  }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    click: function(res){

      this.triggerEvent('grab', res.currentTarget.dataset.info)
    }
  }
})
