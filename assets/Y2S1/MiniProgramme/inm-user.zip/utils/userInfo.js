export async function getInfo() {
  return new Promise((resolve, rejected) => {
    wx.getUserInfo({
      lang: 'zh_CN',
      withCredentials: true,
      success: (res) => {
        console.log(res)
        resolve(res)
      },
      fail: (res) => {
        rejected(res)
      }
    })
  })
}
