import axios from 'axios'
import mpAdapter from 'axios-miniprogram-adapter'
axios.defaults.adapter = mpAdapter

// const service = axios.create({
//   baseURL: "http://106.14.209.25:8080"
// })

const prefix = "http://localhost"

const product_port = ":8002/product/"
const member_port = ":8001/member/"
const users_port = ":8003/users/"

export default axios
export {
  product_port,
  member_port,
  users_port,
  prefix
} 