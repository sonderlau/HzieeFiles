import axios from '../../utils/request'
import {prefix, product_port} from '../../utils/request'


const service = axios.create({
    baseURL: prefix + product_port
})

export default service