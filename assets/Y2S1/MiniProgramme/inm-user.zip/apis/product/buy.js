import request from './index'


/**
 *   购买相关API
 */



/**
 * 获取到最近的店家
 * @param {*} longitude 经度
 * @param {*} latitude  纬度
 */
 export function getNearestMerchant(longitude, latitude) {

    return request({
        method: 'get',
        url: '/orders/merchants/get',
        params: {
            longitude,
            latitude
        }
    })
 }

 /**
  * 获取指定商家的在售商品
  * @param {string} m_id 商家id
  */
 export function getProducts(m_id) {
     return request({
         method: 'get',
         url: '/merchant/products/getAllProducts',
         params:{
             m_id
         }
     })
 }

/**
 * 
 * @param {string} m_id 店家id
 * @param {string} openId 用户id
 * @param {Array} commodities 商品数组
 * @param {int} type 购买类型
 * @param {string} coupon_key 使用的优惠券
 * @param {int} payment 花费的价格
 */
 export function buyItems(m_id, openId, commodities, type, coupon_key, payment) {
     return request.post(
         '/merchant/buy',
         {
             m_id : Number(m_id),
             openId,
             buyProductVos: commodities,
             type,
             coupon_key,
             payment: Number(payment)
         }
     )
 }

 
