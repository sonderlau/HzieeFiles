import request from './index'

/**
 * 订单相关api
 */

 export function getOrders(openid){
     return request.get('/orders/orders/get',{
        params:{
            openid
        }
     })
 }