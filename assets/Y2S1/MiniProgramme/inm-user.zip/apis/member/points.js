import request from './index'

/**
 * 积分相关API
 */

 /**
  * 查询积分
  * @param {string} openId 
  */
 export function getPoints(openId) {
     return request({
         method: 'get',
         url: `/points/info/${openId}`
     })
 }
 /**
  * 获取可兑换的物品
  */
 export function getItems() {
     return request({
         method:'get',
         url: '/item/items/get'
     })
 }

 /**
  * 兑换物品
  * @param {string} openId 
  * @param {string} item_id 
  */
 export function redeemItem(openid, item_id) {
     return request.get(
         `/item/items/redeem?openid=${openid}&item_id=${item_id}`)
 }
