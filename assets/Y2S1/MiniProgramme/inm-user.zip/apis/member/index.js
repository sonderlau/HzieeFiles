import axios from '../../utils/request'
import {prefix, member_port} from '../../utils/request'


const service = axios.create({
    baseURL: prefix + member_port
})

export default service