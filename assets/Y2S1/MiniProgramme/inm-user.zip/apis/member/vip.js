import request from './index'

/**
 * 会员相关API
 */

 /**
  * 获得当前的vip状态
  * @param {string} openId 
  */
 export function getVipStatus(openid) {
     return request.get(
         '/members/vip/get',
         {
            params:{
                openid
            }
         }
     )
 }

 /**
  * 获得所有可用的vip
  */
 export function getAllVips(){
     return request.get(
         '/vip/vip/getAll',
     )
 }

 /**
  * 充值vip
  * @param {string} openId 
  * @param {string} v_id 会员类型的id
  * @param {int} number 月数
  */
 export function rechargeVip(openId, v_id, number) {
     return request.post(
         '/members/vip/recharge',
        {openId, v_id, number}
     )
 }