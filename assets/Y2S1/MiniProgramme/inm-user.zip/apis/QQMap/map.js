import map from "./index";
const SK = "K5j83kHQC6XuJH7msWYuTnYpG5iTS2d4"

/**
 * 由坐标获取到位置信息
 * @param {double} longitude 纬度
 * @param {double} latitude 经度
 */
export function getAddress(longitude, latitude) {
  console.log(SK);
  return new Promise((resolve, rejected) => {
    map.reverseGeocoder({
      location: {
        latitude: latitude,
        longitude: longitude,
      },
      sig: SK,
      success: function (res) {
        resolve(
          res.result.ad_info.city + res.result.formatted_addresses.recommend
        );
      },
      fail: (res) => {
        rejected(res);
      },
    });
  });
}

/**
 * 计算两个坐标之间的距离
 * @param {object} param0 起始地点的坐标object
 * @param {object} param1 终点坐标的object
 */
export function calcDistance({from_longitude, from_latitude}, {to_longitude, to_latitude}) {
    return new Promise((resolve, rejectd) => {
        map.calculateDistance({
            mode: "walking",
            from: {
                longitude: from_longitude,
                latitude: from_latitude
            },
            to: [
                {
                    longitude: to_longitude,
                    latitude: to_latitude
                }
            ],
            sig: SK,
            success: (res) => {
                resolve(res)
            },
            fail: (res) => {
                rejectd(res)
            }
        })
    })
}