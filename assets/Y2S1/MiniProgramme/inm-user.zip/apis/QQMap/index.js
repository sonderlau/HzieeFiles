import QQMapSDK from '../../utils/qqmap-wx-jssdk.min'

const QQMapKey = "IRKBZ-C2GRD-DNV4M-PKSTG-DD6TE-6VBHU"
const SK = "K5j83kHQC6XuJH7msWYuTnYpG5iTS2d4"

const map = new QQMapSDK({
    key: QQMapKey
})

export default map
export {SK}