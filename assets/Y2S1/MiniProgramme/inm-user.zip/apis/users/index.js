import axios from '../../utils/request'
import {prefix,users_port} from '../../utils/request'


const service = axios.create({
    baseURL: prefix+ users_port,
    
})

export default service