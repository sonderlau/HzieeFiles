import request from './index'

/**
 * 登录相关的 API
 */


 /**
  * 登录并获取openId
  * @param {string} code code值
  */
 export function login(code){
     return request.post(
         '/user/login',
         {code}
     )
 }