import request from './index'

/**
 * 拼团相关API
 */


 /**
  * 获得可用的拼团
  */
 export function getGroupings() {
     return request.get(
         '/group/grouping/get'
     )
 }

 /**
  * 参与拼团
  * @param {string} openId 用户的id
  * @param {string} g_id 拼团活动的id
  */
 export function joinGrouping(openid, gid) {
     return request.post(
         '/groupuser/grouping/join',
         {openid, gid}
     )
 }