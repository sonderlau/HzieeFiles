import request from './index'

/**
 * 拼团相关的API
 */


 /**
  * 获得当前用户的所有优惠券
  * @param {string} openId 用户的id
  */
 export function getCoupons(openId) {
     return request.get(
         '/coupon/coupon/get',
         {params:{
             openId
         }}
     )
 }

 /**
  * 激活优惠券
  * @param {string} openId 用户的id
  * @param {string} coupon_key 优惠券的key
  */
 export function activateCoupon(openId, coupon_key) {
     return request.get(
         '/coupon/coupon/activate',
         {
             params: {openId, coupon_key}
         }
     )
 }