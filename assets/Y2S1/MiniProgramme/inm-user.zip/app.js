//app.js
import {updataInit} from './miniprogram_npm/wx-updata/index'
import {promisifyAll} from 'wx-promise-pro'
import {login} from './apis/users/login'
App({
  onLaunch: function () {
    // Login

    // Promise
    promisifyAll()
    // updata
    Page = updataInit(Page, {debug: true})

    wx.pro.login()
    .then(res => {
      login(res.code)
      .then(res => {
        wx.setStorageSync('openId', res.data.data.openid)
      })
    })
    

  },
  globalData: {

  }
})