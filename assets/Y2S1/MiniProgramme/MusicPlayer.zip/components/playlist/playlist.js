// components/playlist/playlist.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    playlist:{
      type: Array
    },
    current: {
      type: Number,
      value: 0
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    change: function(res){
      console.log(res)
      // 切换歌曲
      this.triggerEvent("changeMusic",{
        info: res.currentTarget.dataset.info,
        index: this.data.current
      })
      
    }
  }
})
