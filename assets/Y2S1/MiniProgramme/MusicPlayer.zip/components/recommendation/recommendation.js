// components/recommendation/recommendation.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    
  },

  /**
   * 组件的初始数据
   */
  data: {
    all_recommendation: [],
    recommendation: [],
    round: 0
  },

  lifetimes:{
    attached: function(){
      let that = this;
      // 获取每日推荐
      wx.request({
        url: 'http://localhost:8080/music/recommendList',
        method:"GET",
        success: function(res){
          console.log(res.data.data)
          that.setData({
            all_recommendation: res.data.data,
            recommendation: res.data.data[that.data.round]
          })
        }
      })
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    pickMusic:function(res){
      console.log(res);
      // 获取当前歌曲的信息
      let pickedMusicInfo = this.data.recommendation[parseInt(res.currentTarget.dataset.order)];
      this.triggerEvent("pickMusic",pickedMusicInfo)
    },
    changeRound: function(){
      let round = this.data.round;
      round = (round + 1) % 3;
      this.setData({
        round : round,
        recommendation: this.data.all_recommendation[round]
      })
    }
  }
})
