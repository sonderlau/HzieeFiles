const lyricsJs = require('../../miniprogram_npm/lyrics.js/index');
// components/player/player.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    title: {
      type: String,
    },
    author: {
      type: String
    },
    album: {
      type: String,
      value: "../../images/cover.jpg"
    },
    duration: {
      type: String,
      value: "00:00"
    },
    percent: {
      type: Number
    },
    currentTime: {
      type: String,
      value: "00:00"
    },
    currentTimeRaw:{
      type:Number
    },
    state: {
      type: Boolean
    },
    lyric: {
      type: String
    }
  },
  observers: {
    'lyric': function (lrc) {
      let that = this;
      console.log(lrc);
      wx.request({
        url: lrc,
        header: {
          'content-type': 'application/octet-stream'
        },
        success: function (res) {
          let lrc = new lyricsJs(res.data);
          that.setData({
            lyricArray: lrc.lyrics_all,
            lyricData: res.data
          })
        }
      })
    },
    // 时间对应的歌词
    'currentTimeRaw': function(res){
      if (res){
        let lrc = new lyricsJs(this.data.lyricData);
        // 单个歌词的高度
        const singleElementHeight = 80;
        // 去负数
        let lrcIndex = lrc.select(res) < 0 ? 0 : lrc.select(res);
        // 开始移动所需要达到的的最小歌词数 即占满半个屏幕需要多少行歌词
        let minimum = this.data.scrollViewHeight / 2 / singleElementHeight ;
        // 计算移动距离
                        // 查看当前歌词距离顶部的距离是否达到 当前组件高度的一半           没达到则不移动  达到则 减去最小的移动的行数 并计算移动值                                                           
        let setCenter = (lrcIndex+1) * singleElementHeight < this.data.scrollViewHeight / 2 ? 0 : ((lrcIndex + 1) * singleElementHeight - this.data.scrollViewHeight * 0.5 );
        this.setData({
          moveToLyric: Math.floor(setCenter),
          currentLyricIndex: lrcIndex
        })
      }
      
      
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    isLyric: false,
    lyricArray: [],
    currentLyricIndex: "0"
  },

  lifetimes: {
    attached: function() {
      this.calculateHeight();
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    sliderChange(res) {
      this.setData({
        percent: res.detail.value
      })

      this.triggerEvent('changeMusicPercent', res.detail.value)

    },
    // 切换界面
    changeLyric(res) {
      console.log(res);
      this.setData({
        isLyric: res.currentTarget.dataset.lyric == "true" ? false : true
      })


    },
    calculateHeight() {
      //! 计算高度 并设置滑动的高度
      const query = wx.createSelectorQuery();
      query.selectViewport().fields({
        size: true,
      });
      query.exec((res) => {
        let pageHeight = parseInt(res[0].height);
        let pageWidth = parseInt(res[0].width);
        this.setData({
          scrollViewHeight: pageHeight - (112 + 80) / 750 * pageWidth
        })
        
      });
    }

  }
})