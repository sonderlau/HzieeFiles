//index.js

const { standarlizeTime } = require('../../utils/util')
const MAXIMUM = 9;
//获取应用实例

Page({
  data: {
    item: 0,
    tab: 0,
    // 播放信息相关
    music_title: "未知歌曲",
    music_author: "Unknown",
    music_duration: "00:00",
    music_currentTime: "00:00",
    music_paused: true,
    music_loop:false,
    music_volume: 0.5,
    music_album: "../../images/cover.jpg",
    music_lyric:"https://newborn-treasure.oss-cn-hangzhou.aliyuncs.com/miniprogramme/Car%20Park-Fenne%20Lily.lrc",
    music_percent: 0,

    playlist:[],      // 播放列表的歌曲数组
    currentIndex: 0,  // 当前播放的是播放列表的第几个
    recommendation: [],    // 整个推荐的数据
    recommendation_round: 0 // 推荐的轮次
  },

  changeItem: function (e) {
    this.setData({
      item: e.target.dataset.item,
    })
  },
  // tab切换
  changeTab: function (e) {
    this.setData({
      tab: e.detail.current
    })
  },
  // 切换到列表页面
  changePage: function(){
    this.setData({
      item: 2
    })
  },

  audio_context:null,
  // 暂停
  pause: function() {
    this.audio_context.pause();
    this.setData({
      music_paused: true
    })
  },
  // 播放
  play: function() {
    this.audio_context.play();
    this.setData({
      music_paused: false,
    })
  },
  // 下一首
  next: function(){
    let newCurrentIndex = (this.data.currentIndex + 1) % this.data.playlist.length;
    // 播放歌曲
    this.playPickedMusic(this.data.playlist[newCurrentIndex],newCurrentIndex)
  },

  // 从播放列表中挑选了歌曲
  pickMusic:function(res){
    console.log(res);
    // 播放列表插入歌曲
    let playlist_array = this.data.playlist;
    // 设置当前播放的 index
    let index;
    for(let i = 0 ; i < playlist_array.length ; i ++){
      if (playlist_array[i].id === res.detail.info.id){
        index = i;
      }
    }
    // 播放当前音乐
    this.playPickedMusic(res.detail.info,index);
  },

  // 从推荐中选取了歌曲
  pickRecommendationMusic: function(res){
    console.log(res)
    // 播放列表插入歌曲
    let playlist_array = this.data.playlist;
    // 查找当前列表内是否有 即将要播放的歌曲
    
    
    let flag = true;
    playlist_array.forEach((element,index) => {
      if (element.id === res.detail.id){
        // 有 删除该歌曲 并将即将播放的歌曲放到最后一个
        flag = false;
        playlist_array.splice(index,1)
      }
    });
    if (flag){
      // 没有 删除第一个 并将即将播放的歌曲放到最后一个
      playlist_array.shift();
    }
    playlist_array.push(res.detail);

    this.setData({
      playlist: playlist_array
    })

    this.playPickedMusic(res.detail,playlist_array.length - 1);
  },

  // 传入音乐的object 播放音乐
  playPickedMusic: function(res,currentIndex){
    this.audio_context.src = res.src;
    this.audio_context.pause();
    this.setData({
      // 音乐信息
        // 从 0 开始播放
      music_currentTime: standarlizeTime(0),
      currentTimeRaw:this.audio_context.currentTime,
      music_percent: this.audio_context.currentTime / this.audio_context.duration * 100,
      music_duration: standarlizeTime(this.audio_context.duration),
      music_title: res.title,
      music_lyric: res.lyric,
      music_album: res.album,
      music_author: res.author,
      // 播放列表的进度
      currentIndex: currentIndex ? currentIndex : 0
    })
    // 延迟后播放 让数据生效
    setTimeout(()=>{
      this.play()
    }, 400);

    // 提供给服务器 最新听的歌曲
    let openid = wx.getStorageSync('openId');
    wx.request({
      url: 'http://127.0.0.1:8080/music/addSong',
      method: "GET",
      data: {
        id: res.id,
        openid: openid
      },
      success: function(res){
        console.log(res)
      },
      fail: function(res){
        console.log(res)
      }
    })

    // 修改当前的 播放列表 数组
    //let playlist_array = this.data.playlist;
    // if(playlist_array.length = MAXIMUM){
    //   // 已经达到最大的存量了
    //   playlist_array.pop();
    // }
    //playlist_array.unshift(res);
  },
  onLoad: function () {
      this.audio_context = wx.createInnerAudioContext();
      this.audio_context.volume = this.data.music_volume;
      
      this.audio_context.onTimeUpdate(()=>{
        
        this.setData({
          music_currentTime: standarlizeTime(this.audio_context.currentTime),
          currentTimeRaw:this.audio_context.currentTime,
          music_percent: this.audio_context.currentTime / this.audio_context.duration * 100,
          music_duration: standarlizeTime(this.audio_context.duration)
        })
        
      })
  },
  // 切换音乐进度
  changeMusicPercent: function(res){
    // api的bug问题 先暂停
    this.audio_context.pause();
    this.audio_context.seek(this.audio_context.duration * (res.detail / 100))
    // 更新进度
    this.setData({
      music_percent: res.detail ,
      music_currentTime: standarlizeTime(res.detail / 100 * this.audio_context.duration),
      currentTimeRaw: res.detail / 100 * this.audio_context.duration
    })
    this.audio_context.onSeeked(()=>{
      if(!this.data.music_paused){
        // 在非暂停状态下的切换进度 才进行播放
        this.audio_context.play();
      } 
    })
    
  },
  onShow: function(){
     // 获取历史播放列表
      // 
      let that = this;
      wx.request({
        url: 'http://localhost:8080/music/playlist',
        data: {
          openid: wx.getStorageSync('openId')
        },
        method: "GET",
        success: function(res){
           console.log(res)
          // 更新
          let index;
          console.log(res.data.data.list)
          console.log(res.data.data.current)
          for (let i = 0; i < res.data.data.list.length ; i++ ){
            if (res.data.data.list[i].id === res.data.data.current){
              // 找到对应的id
              index = i;
            }
          }
          console.log(index)
          // 播放 音乐
          // console.log(res.data.data.list[currentIndex])
          that.playPickedMusic(res.data.data.list[index]);
          that.setData({
            playlist: res.data.data.list,
            currentIndex: index
          })
          setTimeout(() => {
            that.pause();
          }, 500);
        },
        fail:function(res){
          console.log(res)
        }
      })

      

      
  },
  onUnload: function(){
   
    
  }
})