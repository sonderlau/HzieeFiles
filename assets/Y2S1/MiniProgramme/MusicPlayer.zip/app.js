//app.js
App({
  onLaunch: function () {
    if (!wx.getStorageSync('openId')) {
      // 没登陆过
      // 登录
      wx.login({
        success: res => {
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          wx.request({
            url: 'http://127.0.0.1:8080/cis/',
            data:{
              code: res.code
            },
            success: function(res){
              console.log(res)
              wx.setStorageSync('openId', res.data.data.openid)
            },
            fail: function(res){
              console.warn(res)
            }
          })

          // 

        }
      })
    }

  },
  globalData: {
    userInfo: null
  }
})