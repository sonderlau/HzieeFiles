function standarlizeTime(time){
  let minute = Math.floor(time / 60) % 60;
  let second = Math.floor(time) % 60;
  return (minute < 10 ? '0'+minute : minute) + ":" + (second < 10 ? '0'+second : second);
}

module.exports = {
  standarlizeTime
}
