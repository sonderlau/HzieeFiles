import Vue from 'vue'
import ElementUI from 'element-ui'
import { ElementTiptapPlugin } from 'element-tiptap'
// 引入 ElementUI 样式
import 'element-ui/lib/theme-chalk/index.css'
// import element-tiptap 样式
import 'element-tiptap/lib/index.css'

Vue.prototype.$message = ElementUI.Message

Vue.prototype.$confirm = ElementUI.MessageBox.confirm

Vue.prototype.$notify = ElementUI.Notification

Vue.use(ElementUI)
Vue.use(ElementTiptapPlugin, {
  lang: 'zh'
})
