import Vue from 'vue'
import VueRouter from 'vue-router'

// 路由懒加载
const Login = () => import(/* webpackChunkName: "Login_Home_Welcome" */ '../Views/Login.vue')
const Home = () => import(/* webpackChunkName: "Login_Home_Welcome" */ '../Views/Home.vue')
const Welcome = () => import(/* webpackChunkName: "Login_Home_Welcome" */ '../Views/Welcome.vue')

const Profile = () => import('../components/PersonalZone/Profile')
const Grouping = () => import('../components/Grouping/Grouping')

const Goods = () => import('../components/Storage/Goods')
const Storage = () => import('../components/Storage/Storage')

const Orders = () => import('../components/Order/Order')

const RequirementDetails = () => import('@/Views/RequirementDetails')

Vue.use(VueRouter)

const routes = [
  { path: '/', redirect: '/info' },
  { path: '/info', component: Login },
  { path: '/home',
    component: Home,
    redirect: '/Welcome',
    children: [
      { path: '/home', component: Welcome },
      { path: '/details', component: RequirementDetails, name: 'details' },
      { path: '/profile', component: Profile },
      { path: '/grouping', component: Grouping },
      { path: '/storage', component: Storage },
      { path: '/goods', component: Goods },
      { path: '/orders', component: Orders }
    ] }

]

const router = new VueRouter({
  routes
})

// 挂载路由导航守卫,to表示将要访问的路径，from表示从哪里来，next是下一个要做的操作 next('/info')强制跳转login
router.beforeEach((to, from, next) => {
  // 访问登录页，放行
  if (to.path === '/info') return next()
  // 获取token
  const tokenStr = window.sessionStorage.getItem('token')
  // 没有token, 强制跳转到登录页
  if (!tokenStr) {
    this.$message.error('请先登录!')
    return next('/info')
  }
  next()
})

export default router
