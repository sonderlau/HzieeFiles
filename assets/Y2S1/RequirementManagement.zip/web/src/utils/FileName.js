/**
 * 获取文件的名称
 * @param file
 * @returns {*}
 */
export function getFileName (file) {
  //* 寻找是否有 /
  let lastSlash = file.lastIndexOf('-')
  let lastDot = file.lastIndexOf('.')
  return file.slice(lastSlash, lastDot)
}

/**
 * 获取文件的类型
 * @param file
 * @returns {string}
 */
export function getFileType (file) {
  return file.substr(file.lastIndexOf('.') + 1)
}
