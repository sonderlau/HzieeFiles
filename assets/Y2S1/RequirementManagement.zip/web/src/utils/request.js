
const base = 'http://localhost:8080'

const UserPrefix = '/users'
const ProjectPrefix = '/product'

export {
  base,
  UserPrefix,
  ProjectPrefix
}
