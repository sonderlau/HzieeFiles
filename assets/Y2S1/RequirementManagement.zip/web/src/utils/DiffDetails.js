
export function diffDetails (detailsFirst, detailsSecond) {
  const details1 = detailsFirst === null ? '' : detailsFirst
  const details2 = detailsSecond === null ? '' : detailsSecond
  const Diff = require('diff')
  let resultHTML = ''
  const diff = Diff.diffChars(details1, details2)
  diff.forEach(part => {
    const color = part.added ? 'green'
      : part.removed ? 'red' : 'grey'
    resultHTML += colorWrap(color, part.value)
  })

  return resultHTML

  function colorWrap (color, content) {
    switch (color) {
      case 'green':
        return `<span style="color: green;background-color: rgb(236, 253, 240)">${content}</span>`
      case 'red':
        return `<span style="color: red;background-color: rgb(251, 233, 235)">${content}</span>`
      case 'grey':
        return `<span>${content}</span>`
    }
  }
}

export function diffAttachments (att1, att2) {
  const Diff = require('diff')
  let result = {
    added: [],
    removed: []
  }
  //* 对附件数组进行处理
  let md5No1 = []; let md5No2 = []
  let mapNo1 = new Map(); let mapNo2 = new Map()
  att1.forEach(element => {
    md5No1.unshift(element.md5)
    mapNo1.set(element.md5, element)
  })
  att2.forEach(element => {
    md5No2.unshift(element.md5)
    mapNo2.set(element.md5, element)
  })

  Diff.diffArrays(md5No1, md5No2).forEach(element => {
    if (element.added) {
      result.added.unshift(mapNo2.get(element.value[0]))
    } else if (element.removed) {
      result.removed.unshift(mapNo1.get(element.value[0]))
    }
  })

  return result
}
