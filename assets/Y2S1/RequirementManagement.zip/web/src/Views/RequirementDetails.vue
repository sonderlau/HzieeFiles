<template>
<div style="display: flex;flex-direction: column;align-items: center">
  <el-button style="align-self: flex-end" @click="save">保存</el-button>
  <el-button style="align-self: flex-end" @click="openDiff">比对版本</el-button>
  <el-button style="align-self: flex-end" @click="openRollback">回滚版本</el-button>
  <h2>需求详情:</h2>

  <Editor style="width: 1000px" ref="editor" :content="content"></Editor>
<!-- 附件 -->
  <h2>附件:</h2>

  <el-table
    :data="requirementDetails.attachments"
    style="width: 50%">
    <el-table-column
      label="文件名"
      width="80">
        <template slot-scope="scope">
          {{getFileName(scope.row.src)}}
        </template>
    </el-table-column>
    <el-table-column
      prop="type"
      label="文件类型"
      width="50">
    </el-table-column>
    <el-table-column
      prop="src"
      label="下载">
      <template slot-scope="scope">
        <el-button type="primary" round @click="downloadFile(scope.row.src)" >下载</el-button>
      </template>
    </el-table-column>
    <el-table-column label="md5">
      <template  slot-scope="scope" >
        <el-tooltip :content="scope.row.md5" effect="dark" placement="right">
          <el-tag>MD5</el-tag>
        </el-tooltip>
      </template>

    </el-table-column>
  </el-table>

  <h2>上传文件:</h2>
  <el-upload style="margin-bottom: 30px" drag="" action="" :http-request="cosUpload">

  </el-upload>

<!-- 比对-->
  <el-drawer title="版本比对" :visible.sync="diffShow" direction="rtl">
    <h4>当前版本: {{versions.current}}</h4>
<!--    一个版本-->
    <el-select v-model="versionOne" placeholder="请选择">
      <el-option
        v-for="item in versions.history"
        :key="item.version"
        :value="item.version"
        :label="item.label">
        <el-tooltip :content="item.version" placement="left">
          <span :class="item.version === versions.current ? 'highlight' : ''">@{{ item.version.slice(0, 6) }}</span>
        </el-tooltip>

      </el-option>
    </el-select>

<!--    另外一个版本-->
    <el-select v-model="versionTwo" placeholder="请选择">
      <el-option
        v-for="item in versions.history"
        :key="item.version"
        :value="item.version">
        <el-tooltip  :content="item.version" placement="right">
          <span :class="item.version === versions.current ? 'highlight' : ''">@{{ item.version.slice(0, 6) }}</span>
        </el-tooltip>

      </el-option>
    </el-select>

    <el-button type="primary" @click="processDiff">进行比对</el-button>
<!--内容的对比-->
    <div style="margin: 30px 20px" v-show="diffResult" v-html="diffResult"></div>
<!--    附件的对比-->
    <div>
      <h3  v-show="diffAttachmentResult.added.length > 0">增加的附件:</h3>
<!--      增加的-->
      <el-table v-show="diffAttachmentResult.added.length > 0" :data="diffAttachmentResult.added">
        <el-table-column
          label="文件名"
          width="80">
          <template slot-scope="scope">
            {{getFileName(scope.row.src)}}
          </template>
        </el-table-column>
        <el-table-column
          prop="type"
          label="文件类型"
          width="50">
        </el-table-column>
        <el-table-column
          prop="src"
          label="下载">
          <template slot-scope="scope">
            <el-button type="primary" round @click="downloadFile(scope.row.src)" >下载</el-button>
          </template>
        </el-table-column>
        <el-table-column label="md5">
          <template  slot-scope="scope" >
            <el-tooltip :content="scope.row.md5" effect="dark" placement="right">
              <el-tag>MD5</el-tag>
            </el-tooltip>
          </template>

        </el-table-column>
      </el-table>

<!--      减少的-->
      <h4 v-show="diffAttachmentResult.removed.length > 0" >减少的附件:</h4>
      <el-table v-show="diffAttachmentResult.removed.length > 0" :data="diffAttachmentResult.removed">
        <el-table-column
          label="文件名"
          width="80">
          <template slot-scope="scope">
            {{getFileName(scope.row.src)}}
          </template>
        </el-table-column>
        <el-table-column
          prop="type"
          label="文件类型"
          width="50">
        </el-table-column>
        <el-table-column
          prop="src"
          label="下载">
          <template slot-scope="scope">
            <el-button type="primary" round @click="downloadFile(scope.row.src)" >下载</el-button>
          </template>
        </el-table-column>
        <el-table-column label="md5">
          <template  slot-scope="scope" >
            <el-tooltip :content="scope.row.md5" effect="dark" placement="right">
              <el-tag>MD5</el-tag>
            </el-tooltip>
          </template>

        </el-table-column>
      </el-table>
    </div>

  </el-drawer>

  <el-drawer title="回滚版本" :visible.sync="rollbackShow" direction="rtl">
    <el-select v-model="versionRollback" placeholder="请选择">
      <el-option
        v-for="item in versions.history"
        :key="item.version"
        :value="item.version">
        <el-tooltip  :content="item.version" placement="right">
          <span :class="item.version === versions.current ? 'highlight' : ''">@{{ item.version.slice(0, 6) }}</span>
        </el-tooltip>

      </el-option>
    </el-select>
    <el-button type="warning" @click="rollback">回滚</el-button>
  </el-drawer>
</div>
</template>

<script>
import {
  getRequirementDetails,
  getTwoRequirementDetails,
  getVersionsOfRequirement,
  rollBackVersion,
  updateRequirement
} from '@/api/project/project'
import Editor from '@/components/Editor/Editor'
import cos from '@/api/cos'
import { getFileMD5 } from '@/utils/FileMD5'
import { getFileType } from '@/utils/FileName'
import { diffAttachments, diffDetails } from '@/utils/DiffDetails'
import axios from 'axios'

export default {
  name: 'RequirementDetails',
  components: {
    Editor
  },
  data () {
    return {
      content: '',
      requirementDetails: {
        requirement_id: []
      },
      diffShow: false,
      versionOne: '',
      versionTwo: '',
      versions: {
        history: [],
        current: ''
      },
      diffResult: '',
      diffAttachmentResult: {
        added: [],
        removed: []
      },
      rollbackShow: false,
      versionRollback: ''
    }
  },
  methods: {
    //* 进行版本回滚
    rollback () {
      rollBackVersion(this.requirementDetails.requirement_id, this.versionRollback)
        .then(() => {
          this.rollbackShow = false
          this.$message.success('回滚成功')
          this.$router.back()
        })
    },
    //* 打开回滚版本的页面
    openRollback () {
      this.rollbackShow = true
      //* 获取历史版本
      getVersionsOfRequirement(this.requirementDetails.requirement_id)
        .then(res => {
          this.versions = res.data.data
          this.versions.history = res.data.data.history.reverse()
        })
    },
    //* 保存
    save () {
      //* 获取到编辑的内容
      console.log(this.$refs.editor.editor.getHTML())
      updateRequirement(this.requirementDetails.requirement_id, this.$refs.editor.editor.getHTML(), this.requirementDetails.attachments)
        .then(() => {
          this.$router.back()
        })
        .catch((res) => {
          this.$message.error(res.data)
        })
    },
    show () {
      console.log(this.$refs.editor.editor.getHTML())
    },
    getFileName (download) {
      let start = download.lastIndexOf('-')
      let end = download.lastIndexOf('.')
      return download.slice(start + 1, end)
    },
    //* 下载文件
    downloadFile (url) {
      window.open(url)
    },
    //* 通过 腾讯 cos 上传文件
    async cosUpload (fileObject) {
      const file = fileObject.file
      let currentFileMd5 = await getFileMD5(file)
      this.cos.putObject({
        Bucket: 'hzieecos-1300064754',
        Region: 'ap-shanghai',
        Key: '/assets/' + currentFileMd5 + '-' + file.name,
        StorageClass: 'STANDARD',
        Body: file,
        onProgress: progressData => {
          console.log(progressData)
        }
      }, (err, data) => {
        console.log(err || data)
        if (data.statusCode === 200) {
          this.$message.success('上传成功')
          //* 对附件的列表处理
          let attachment = {
            md5: currentFileMd5,
            type: getFileType(file.name),
            src: 'https://' + data.Location
          }
          console.log(attachment)
          this.requirementDetails.attachments.push(attachment)
        }
      }
      )
    },
    openDiff () {
      this.diffShow = true
      //* 获取到版本
      getVersionsOfRequirement(this.requirementDetails.requirement_id)
        .then(res => {
          console.log(res)
          this.versions = res.data.data
          this.versions.history = res.data.data.history.reverse()
        })
    },
    //* 进行比对
    processDiff () {
      //* 获取到两个版本的具体信息
      getTwoRequirementDetails({ requirementId1: this.requirementDetails.requirement_id, versionId1: this.versionOne }, { requirementId2: this.requirementDetails.requirement_id, versionId2: this.versionTwo })
        .then(axios.spread((version1, version2) => {
          this.diffResult = diffDetails(version1.data.data.version.details, version2.data.data.version.details)
          this.diffAttachmentResult = diffAttachments(version1.data.data.attachments, version2.data.data.attachments)
        }))
    }
  },
  created () {
    //* 获取需求的详情
    getRequirementDetails(this.$route.query.requirement_id, this.$route.query.version_id)
      .then((res) => {
        console.log(res.data.data)
        this.requirementDetails = res.data.data
        this.$refs.editor.editor.setContent(res.data.data.version.details)
      })
    this.cos = cos
  }
}
</script>

<style scoped>
.highlight {
  color: red;
}
</style>
