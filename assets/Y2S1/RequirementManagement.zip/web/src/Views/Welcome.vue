<template>
  <div style="margin: 10px 15%">
    <el-button @click="addProjectVisible = true">添加项目</el-button>
    <h2>当前拥有的项目:</h2>
    <el-row :gutter="20">
      <el-col :span="8" v-for="(item,index) in owned" :key="index" >
        <el-card shadow="hover" >
          <div slot="header">
            项目: {{item.name}}
          </div>
          拥有者: {{item.ownerName}} <br>
          当前需求数量: {{item.requirementAmount}} <br>

          <el-button type="primary" round @click="checkProject(item.productId)">
            查看需求
          </el-button>

          <el-collapse v-model="visibleUsersActivating" accordion>
            <el-collapse-item title="可访问的用户" :name="item.productId">
              <el-tag closable @close="removeVisibleUser(users,item.productId)" v-for="users in requirementsVisibleUsers" :key="users">{{users}}</el-tag>
            </el-collapse-item>
          </el-collapse>
          <el-button round type="primary" @click="visibleUserVisible = true; openedProjectId = item.productId">添加可访问的用户</el-button>
        </el-card>
      </el-col>
    </el-row>
    <h2>当前可访问的项目:</h2>
    <el-row :gutter="20">
      <el-col :span="8" v-for="(item,index) in visible" :key="index" >
        <el-card shadow="hover" @click="checkProject(item.productId)">
          <div slot="header">
            项目: {{item.name}}
          </div>
          拥有者: {{item.ownerName}} <br>
          当前需求数量: {{item.requirementAmount}}
          <el-button type="primary" round @click="checkProject(item.productId); openedOwned = false">
            查看需求
          </el-button>
          <el-collapse v-model="visibleUsersActivating" accordion>
            <el-collapse-item title="可访问的用户" :name="item.productId">
              <el-tag v-for="item in requirementsVisibleUsers" :key="item">{{item}}</el-tag>
            </el-collapse-item>
          </el-collapse>
        </el-card>
      </el-col>
    </el-row>

    <el-dialog title="需求列表" :visible.sync="requirementsVisible" width="35%">

      <!--      新建需求-->
      <el-dialog :visible.sync="addRequirementVisible" width="40%" append-to-body>
        <el-form v-model="addRequirementForm">
          <el-form-item label="名称">
            <el-input v-model="addRequirementForm.name"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="createRequirement">立即创建</el-button>
          </el-form-item>
        </el-form>
    </el-dialog>
        <el-button v-show="openedOwned" @click="addRequirementVisible = true">新建需求</el-button>

      <!--      内容页面-->
        <el-card v-for="(item,index) in requirementsDialog" :key="index">
          需求名称: <el-tag type="success">{{item.name}}</el-tag><br>
          上一次更新时间:<el-tag type="info">{{item.updated_time}}</el-tag> <br>
          当前版本:
          <el-tooltip placement="bottom" :content="item.version_id">
            <el-tag>
              @{{item.version_id.slice(0, 6)}}
            </el-tag>
          </el-tooltip>
          <el-button @click="checkDetails(item.requirement_id, item.version_id)">
            查看详情
          </el-button>

        </el-card>
    </el-dialog>

<!--    新建项目-->
    <el-dialog title="添加项目" :visible.sync="addProjectVisible" width="40%">
      <el-form v-model="addProjectForm">
        <el-form-item label="名称">
          <el-input v-model="addProjectForm.name"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="createProject">立即创建</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

<!--    可访问者编辑框-->
    <el-dialog title="添加访问者" :visible.sync="visibleUserVisible" width="40%">
      <el-input v-model="visibleUserForm.id"></el-input>
      <el-button round type="primary" @click="addVisibleUser">添加</el-button>
    </el-dialog>
  </div>
</template>

<script>
import { getProjectList, getProjectRequirementList, addProject, addRequirement, getVisibleUsers, addVisibleUsers } from '@/api/project/project'

export default {
  data () {
    return {
      visible: [],
      owned: [],
      requirementsVisible: false,
      requirementsDialog: [],
      addProjectVisible: false,
      addProjectForm: {
        name: ''
      },
      visibleUserVisible: false,
      addRequirementVisible: false,
      addRequirementForm: {},
      requirementsProjectId: 0,
      openedOwned: true,
      visibleUsersActivating: '',
      requirementsVisibleUsers: [],
      visibleUserForm: {
        id: 0
      },
      rollbackVersion: '',
      versionHistory: []
    }
  },
  watch: {
    visibleUsersActivating: function () {
      this.getVisibleUser(this.visibleUsersActivating)
    }
  },
  created () {
    this.getList()
  },
  methods: {
    //* 添加可访问的用户
    addVisibleUser () {
      addVisibleUsers(this.openedProjectId, [this.visibleUserForm.id])
        .then((res) => {
          this.visibleUserVisible = false
          this.$message.success('添加成功')
        })
    },
    //* 获取可访问某项目的用户
    getVisibleUser (res) {
      getVisibleUsers(res)
        .then((res) => {
          this.requirementsVisibleUsers = res.data.data
        })
    },
    //* 创建项目
    createProject () {
      addProject(this.addProjectForm.name, window.sessionStorage.getItem('token'))
        .then(() => {
          this.$message.success('创建项目成功')
          this.addProjectVisible = false
          this.getList()
        })
        .catch(() => {
          this.$message.error('创建失败')
        })
    },
    //* 创建需求
    createRequirement () {
      //* 获取信息并发送
      addRequirement(this.addRequirementForm.name, this.requirementsProjectId)
        .then((res) => {
          this.$message.success('新建成功')
          this.addRequirementVisible = false
          this.checkProject(this.requirementsProjectId)
        })
    },
    //* 获取所有的可查看的项目
    getList () {
      getProjectList(window.sessionStorage.getItem('token'))
        .then((res) => {
          console.log(res)
          this.visible = res.data.data.visible
          this.owned = res.data.data.owned
        })
        .catch((res) => {
          console.log(res)
        })
    },
    //* 查看某一项目的需求
    checkProject (productId) {
      getProjectRequirementList(productId)
        .then((res) => {
          this.requirementsVisible = true
          this.requirementsDialog = res.data.data
          this.requirementsProjectId = productId
        })
        .catch(() => {
          this.$message.error('错误')
        })
    },
    //* 查看需求的具体内容
    // eslint-disable-next-line camelcase
    checkDetails (requirement_id, version_id) {
      this.$router.push({
        name: 'details',
        query: {
          requirement_id,
          version_id
        }
      })
    }
  }

}
</script>

<style scoped>
</style>
