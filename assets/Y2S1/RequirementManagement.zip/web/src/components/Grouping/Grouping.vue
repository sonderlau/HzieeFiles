<template>
  <div>
    <el-table stripe :data="complaintList">
      <el-table-column prop="g_id" label="#"></el-table-column>
      <el-table-column prop="name" label="名称"></el-table-column>
      <el-table-column prop="membership_max" label="人数上限"></el-table-column>
      <el-table-column prop="deadline" label="截止时间"></el-table-column>
      <el-table-column prop="cost" label="参团价格"></el-table-column>
      <el-table-column label="图片" prop="commodityTo" width="450px">
        <img class="infractionImage" slot-scope="scope" :src="scope.row.commodityTo.image" alt="infraction image">
      </el-table-column>
      <el-table-column label="操作">
        <el-button round slot-scope="scope" @click="checkUsers(scope.row.g_id)">查看用户</el-button>
      </el-table-column>
    </el-table>

    <el-dialog title="拼团用户" :visible.sync="requestVisible">
      <div style="margin-top: 5px" v-for="(item,index) in requestForm"  v-bind:key="index">
        <el-tag style="margin-right: 8px">{{item.name}}</el-tag>
        :
        <el-tag style="margin-left: 8px" type="info">{{item.phone}}</el-tag>
      </div>

      <span slot="footer" class="dialog-footer">
        <el-button @click="requestVisible = false">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>

export default {
  name: 'Complaint',
  data () {
    return {
      complaintList: [],
      token: JSON.parse(window.sessionStorage.getItem('token')),
      requestVisible: false,
      requestForm: {}
    }
  },
  created () {

  },
  methods: {
    //* 查看用户
    checkUsers (id) {
      //* 获取到用户列表
    }
  }
}
</script>

<style scoped>
.infractionImage {
  height: 10rem;
}
</style>
