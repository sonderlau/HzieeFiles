<template>
  <div>
      <el-card :body-style="cardStyle">
        <h2>商家信息页面</h2>
        <el-card :body-style="innerCardStyle">
          <el-form label-position="left" label-width="80px" :model="userInfo">
            <el-form-item label="ID">
              <el-input :disabled="true" v-model="userInfo.mid"></el-input>
            </el-form-item>
            <el-form-item label="坐标">
              {{userInfo.longitutde}},{{userInfo.latitude}}
            </el-form-item>
            <el-divider></el-divider>
<!--            以下是可更改的部分-->
            <el-form-item label="用户名">
              <el-input :disabled.sync="userInfoDisabled" v-model="userInfo.username"></el-input>
            </el-form-item>

            <el-form-item label="密码">
              <el-input :disabled.sync="userInfoDisabled" v-model="userInfo.password" show-password></el-input>
            </el-form-item>
            <el-form-item label="店名">
              <el-input :disabled.sync="userInfoDisabled" v-model="userInfo.name"></el-input>
            </el-form-item>
            <el-form-item style="float:right;">
              <el-button type="primary" plain @click="userInfoDisabled = !userInfoDisabled">修改</el-button>
              <el-button type="success" plain @click="submitProfile">提交</el-button>
            </el-form-item>
          </el-form>
        </el-card >

      </el-card>
  </div>
</template>

<script>
export default {
  name: 'Profile',
  data () {
    return {
      userInfo: {
      },
      userInfoDisabled: true,
      cardStyle: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        alignContent: 'center'
      },
      innerCardStyle: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '15px 35px'
      }
    }
  },
  created () {
    // * 获取个人信息
    let data = JSON.parse(window.sessionStorage.getItem('token')).data
    this.userInfo = data
    this.userInfo.m_id = data.mid
  },
  methods: {
    submitProfile () {
      //* 发送更新的个人信息
    }
  }
}
</script>

<style scoped>
</style>
