<template>
  <div class="icon" :class="[`icon--${name}`, `icon--${size}`, { 'has-align-fix': fixAlign }]">
    <img :src="require(`@/assets/images/icons/${name}.svg`)" :alt="name"/>
  </div>
</template>

<script>
export default {
  props: {
    name: {},
    size: {
      default: 'normal'
    },
    modifier: {
      default: null
    },
    fixAlign: {
      default: true
    }
  }
}
</script>

<style scoped>
.icon {
  position: relative;
  display: inline-block;
  vertical-align: middle;
  width: 0.8rem;
  height: 0.8rem;
  margin: 0 .3rem;
  top: -.05rem;
  fill: currentColor;
}

.icon__svg {
  display: inline-block;
  vertical-align: top;
  width: 100%;
  height: 100%;
}

.icon:first-child {
  margin-left: 0;
}

.icon:last-child {
  margin-right: 0;
}

body > svg path,
body > svg rect,
body > svg circle,
body > svg g,
.icon use > svg path,
.icon use > svg rect,
.icon use > svg circle,
.icon use > svg g,
symbol path,
symbol rect,
symbol circle,
symbol g {
  fill: currentColor;
  stroke: none;
}

body > svg *[d="M0 0h24v24H0z"],
.icon use > svg *[d="M0 0h24v24H0z"],
symbol *[d="M0 0h24v24H0z"] {
  display: none;
}

</style>
