<template>
  <div>

    <el-table border stripe :data="list">
      <el-table-column prop="c_id" label="#" width="30px"></el-table-column>
      <el-table-column prop="details.name" label="名称" width="100px"></el-table-column>
      <el-table-column prop="inbound_date" label="入库时间"></el-table-column>
      <el-table-column prop="amount" label="数量"></el-table-column>
      <el-table-column prop="shelf_life" label="保质期"></el-table-column>
      <el-table-column prop="details.property" label="口味">
        <template  v-if="scope.row.details.taste.length !== 0"  slot-scope="scope">
          <el-tag v-for="(item,index) in scope.row.details.taste"
                  :key="index" effect="dark" type="success">{{item.name}} : ¥{{item.value}}</el-tag>
        </template>
        <template v-else>
          <el-tag type="success">无</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="details.property" label="口味">
        <template  v-if="scope.row.details.property.length !== 0"  slot-scope="scope">
          <el-tag v-for="(item,index) in scope.row.details.property"
                  :key="index" effect="dark" type="success">{{item.name}} :{{item.action.delta === 'add' ? '+': '-'}} ¥{{item.action.value}}</el-tag>
        </template>
        <template v-else>
          <el-tag type="success">无</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="图片">
        <img style="height: 10rem;" slot-scope="scope" :src="scope.row.details.image" alt="infraction image">
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="success" size="mini" @click="changeInbound(scope.row)">更改信息</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="更改信息"
               :visible.sync="storageVisible"
               width="50%" @close="storageClosed">
      <!-- 内容主体 -->
      <el-form
        :model="storageForm"
        label-width="100px">
        <el-form-item label="名称">
          <el-input disabled v-model="storageForm.details.name"></el-input>
        </el-form-item>
        <el-form-item label="保质期">
          <el-input-number v-model="storageForm.shelf_life" :min="0" :max="500" label="保质期"></el-input-number>
        </el-form-item>
        <el-form-item label="数量">
          <el-input-number v-model="storageForm.amount" :min="1" :max="500" label="数量"></el-input-number>
        </el-form-item>
        <el-form-item label="入库日期">
          <el-date-picker
            v-model="storageForm.inbound_date"
            type="datetime"
            placeholder="选择日期时间">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="storageVisible = false">取 消</el-button>
        <el-button type="primary" @click="update">确 定</el-button>
      </span>
    </el-dialog>

  </div>

</template>

<script>

export default {
  name: 'Infraction',
  data () {
    return {
      searchVisible: false,
      activeName: 'first',
      query: {
        userId: '',
        addTime: '',
        status: ''
      },
      list: [],
      storageVisible: false,
      storageForm: {
        details: {
          value: 0
        }
      }
    }
  },
  created () {
    this.getInbound()
  },
  methods: {
    getInbound () {
      //* 获取库存信息
      let mid = JSON.parse(window.sessionStorage.getItem('token')).data.mid
      console.log(mid)
    },
    changeInbound (row) {
      //* 更改信息
      console.log(row)
      this.storageForm = row
      this.storageVisible = true
    },
    update () {
    },
    storageClosed () {
      this.storageVisible = false
    },
    getExactTime (date) {
      const year = date.getFullYear() + '-'
      const month = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-'
      const dates = date.getDate() + ' '
      const hour = date.getHours() + ':'
      const min = date.getMinutes() + ':'
      const second = date.getSeconds()
      return year + month + dates + hour + min + second
    }
  }
}
</script>

<style scoped>

</style>
