const COS = require('cos-js-sdk-v5')
const cos = new COS({
  SecretId: 'AKIDcB8nBNZzOkvwfOjzzoMddODtQgiTcCrX',
  SecretKey: 'kTv6rL6ZH8iZ8vqUR91265sov7By1nJX'
})

export default cos
