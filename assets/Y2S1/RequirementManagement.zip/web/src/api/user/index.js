import axios from 'axios'
import { base, UserPrefix } from '@/utils/request'

const service = axios.create({
  baseURL: base + UserPrefix
})

export default service
