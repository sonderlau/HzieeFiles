import axios from 'axios'
import { base, ProjectPrefix } from '@/utils/request'

const service = axios.create({
  baseURL: base + ProjectPrefix
})

export default service
