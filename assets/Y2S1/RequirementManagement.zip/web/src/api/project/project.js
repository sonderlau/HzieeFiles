import service from 'axios'

/**
 * 获取当前用户可以查看的项目列表
 * @param userId
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getProjectList (userId) {
  return service.get(`/product/${userId}/product/list`)
}

/**
 * 获取某项目的所有需求
 * @param projectId
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getProjectRequirementList (projectId) {
  return service.get(`/product/projectRequirements/${projectId}`)
}

/**
 * 删除一个项目或者需求
 * @param type  类型 可选值为 Requirement Project
 * @param value id值
 * @param userId  用户id
 * @returns {Promise<AxiosResponse<any>>}
 */
export function deleteProjectOrRequirement (type, value, userId) {
  return service.delete(`/product/delete/${type}`, {
    params: {

    }
  })
}

/**
 * 获取需求的所有版本
 * @param requirementId
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getVersionsOfRequirement (requirementId) {
  return service.get(`/product/getAll/${requirementId}`)
}

/**
 * 回滚版本
 * @param requirementId 需求id
 * @param versionId 将要回滚的版本id
 * @returns {Promise<AxiosResponse<any>>}
 */
export function rollBackVersion (requirementId, versionId) {
  return service.get('/product/Old', {
    params: {
      requirementId,
      versionId
    }
  })
}

/**
 * 获取某一需求某一版本的详细内容
 * @param requirementId
 * @param versionId
 * @returns {Promise<AxiosResponse<any>>}
 */
export function getRequirementDetails (requirementId, versionId) {
  return service.get('/product/get/aLLVersionRequirements', {
    params: {
      requirementId,
      versionId
    }
  })
}

export function getTwoRequirementDetails ({ requirementId1, versionId1 }, { requirementId2, versionId2 }) {
  return service.all([
    getRequirementDetails(requirementId1, versionId1),
    getRequirementDetails(requirementId2, versionId2)
  ])
}

/**
 * 更新需求的内容
 * @param requirement_id  待更新需求的id
 * @param details 需求的html内容
 * @param attachments 附件数组
 * @returns {Promise<AxiosResponse<any>>}
 */
// eslint-disable-next-line camelcase
export function updateRequirement (requirement_id, details, attachments) {
  return service.put('/product/update', {
    requirement_id,
    details,
    attachments
  })
}

/**
 * 新增项目的需求
 * @param name
 * @param project_id
 * @returns {Promise<AxiosResponse<any>>}
 */
// eslint-disable-next-line camelcase
export function addRequirement (name, project_id) {
  return service.post('/product/addR',
    {
      name,
      project_id
    })
}

/**
 * 获取项目可访问的用户id列表
 * @param project_id  项目的id
 * @returns {Promise<AxiosResponse<any>>}
 */
// eslint-disable-next-line camelcase
export function getVisibleUsers (project_id) {
  return service.get('/product/getU', {
    params: {
      project_id
    }
  })
}

/**
 * 增加项目可访问的用户
 * @param project_id
 * @param user_id int类型数组
 */
// eslint-disable-next-line camelcase
export function addVisibleUsers (project_id, user_id) {
  return service.post('/product/addu', {
    project_id,
    user_id
  })
}

// eslint-disable-next-line camelcase
export function addProject (name, owner_id) {
  return service.post('/product/addProject', {
    name,
    owner_id
  })
}
