package com.hziee.manage.sys.vo;

import lombok.Data;

import java.util.Date;

@Data
public class VersionIdVo {

    private Date updatedTime;
    private String currentVersion;
}
