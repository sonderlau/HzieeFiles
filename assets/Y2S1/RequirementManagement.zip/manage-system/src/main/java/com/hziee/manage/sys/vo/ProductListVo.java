package com.hziee.manage.sys.vo;

import lombok.Data;

import java.util.List;

@Data
public class ProductListVo {
    private List<Product> owned;
    private List<Product> visible;

    @Data
    public static class Product{
        private Integer productId;
        private String name;
        private String ownerName;
        private Integer requirementAmount;
    }
}
