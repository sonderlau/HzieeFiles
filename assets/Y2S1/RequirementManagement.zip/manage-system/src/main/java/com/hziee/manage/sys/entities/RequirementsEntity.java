package com.hziee.manage.sys.entities;


import lombok.Data;

import java.util.Date;

@Data
public class RequirementsEntity {
    private Integer requirement_id;
    private String version_id;
    private String name;
    private Date updated_time;
}
