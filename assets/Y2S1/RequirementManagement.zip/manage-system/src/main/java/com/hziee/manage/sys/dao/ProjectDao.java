package com.hziee.manage.sys.dao;

import com.hziee.manage.sys.entities.*;
import com.hziee.manage.sys.utils.R;
import com.hziee.manage.sys.vo.RequirementsVo;
import org.apache.ibatis.annotations.*;

import java.util.Date;
import java.util.List;

@Mapper
public interface ProjectDao {

    @Select("select * from project_users where project_id = #{project_id}")
    List<ProjectUsersEntity> findPU(Integer project_id);

    @Select("select * from project where owner_id = #{userId}")
    List<ProjectEntity> findByOwnerId(Integer userId);

    @Select(("select * from project_requirements where project_id = #{project_id}"))
    List<ProjectRequirementsEntity> findAmount(Integer project_id);

    @Select("select * from user where user_id = #{owner_id}")
    UserEntity findOwnerNameById(Integer owner_id);

    @Select("select * from project_users where user_id = #{userId}")
    List<ProjectUsersEntity> findByUserId(Integer userId);

    @Select("select * from project where project_id = #{project_id}")
    ProjectEntity findByProjectId(Integer project_id);

    @Select("select * from requirements where ")
    List<R> projectRequirements(Integer projectId);

    @Select("select * from project_requirements where project_id = #{projectId}")
    List<ProjectRequirementsEntity> findPRByprojectId(Integer projectId);

    @Select("select * from requirements where requirement_id = #{requirement_id}")
    RequirementsEntity findRequirements(Integer requirement_id);

    @Select("select * from project_requirements where requirement_id = #{requirement_id}")
    ProjectRequirementsEntity findPRByRequirementId(Integer value);

    @Delete("delete from project_requirements where project_id = #{project_id}")
    void deleteProjectRequirementsBy(Integer project_id);

    @Delete("delete from requirements where requirement_id = #{value}")
    void deletRequirementsBy(Integer value);

    @Delete("delete from project where project_id = #{value}")
    void deleteProjectById(Integer value);

    @Select("select *from requirements where requirement_id = #{requirementId}")
    RequirementsEntity findVersionById(Integer requirementId);

    @Select("select *from version where requirement_id = #{requirementId}")
    List<VersionEntity> findPastVersionById(Integer requirementId);

    @Update("update requirements set version_id = #{version_id} ,updated_time = #{update_time} where requirement_id = #{requirement_id} ")
    void updateRequirement(@Param("requirement_id") Integer requirement_id, @Param("version_id") String version_id,@Param("update_time") Date update_time);

    @Select("select * from version where version_id = #{versionId}")
    VersionEntity findVersion(String versionId);

    @Select("select * from version_attachments where version_id = #{versionId}")
    List<VersionAttachmentsEntity> findVAById(String versionId);

    @Select("select * from attachments where attachments_id = #{attachments_id}")
    AttachmentsEntity findABy(Integer attachments_id);

    @Insert("insert into version (version_id,details,requirement_id) values(#{versionId},#{details},#{requirement_id})")
    void insertVersion(String versionId, String details, Integer requirement_id);

    @Insert("insert into version_attachments (version_id,attachments_id) values(#{versionId},#{attachments_id})")
    void insertVA(String versionId, Integer attachments_id);

    @Insert("insert into attachments (src,type,md5) values(#{src},#{type},#{md5})")
    @Options(useGeneratedKeys=true, keyProperty="attachments_id", keyColumn="id")
    void insertAA(AttachmentsEntity attachmentsEntity);

    @Insert("insert into project(name,owner_id) values(#{name},#{owner_id})")
    @Options(useGeneratedKeys=true, keyProperty="project_id", keyColumn="id")
    void insertproject(ProjectEntity projectEntity);

    @Insert("insert into requirements(version_id,name,updated_time) values(#{versionId},#{name},#{date})")
    void insertR(String versionId,String name,Date date);

    @Select("select * from requirements where version_id = #{encrypt}")
    RequirementsEntity findByRV(String encrypt);

    @Update("update project set requirement_id = #{requirement_id} where project_id = #{project_id}")
    void updateProject(Integer project_id, Integer requirement_id);

    @Insert("insert into project_requirements(project_id,requirement_id) values(#{project_id},#{requirement_id})")
    void insertPR(Integer project_id, Integer requirement_id);

    @Insert("insert into project_users(project_id,user_id) values(#{project_id},#{ussCo})")
    void inseryPU(Integer ussCo, Integer project_id);

    @Insert("insert into version(version_id, requirement_id) values(#{version_id}, #{requirement_id}) ")
    void addVersion(String version_id, Integer requirement_id);

//    @Delete("delete from project_requirements where project_id = #{value}")
//    void deleteProjectRequirementsByPid(Integer value);

}
