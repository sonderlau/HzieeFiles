package com.hziee.manage.sys.vo;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class RequirementsVo {

    private Integer requirement_id;
    private String version_id;
    private String name;
    private Date updated_time;
    private Versions version;
    private List<Attachments> attachments;

    @Data
    public static class Versions{
        private String version_id;
        private String details;
    }

    @Data
    public static class Attachments{
        private String src;
        private String type;
        private String md5;
    }

}
