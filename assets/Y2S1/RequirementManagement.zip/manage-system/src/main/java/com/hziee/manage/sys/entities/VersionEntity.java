package com.hziee.manage.sys.entities;

import lombok.Data;

@Data
public class VersionEntity {
    private String version_id;
    private String details;
    private Integer requirement_id;
}
