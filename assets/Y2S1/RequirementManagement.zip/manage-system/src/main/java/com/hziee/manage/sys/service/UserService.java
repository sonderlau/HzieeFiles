package com.hziee.manage.sys.service;


import com.hziee.manage.sys.entities.UserEntity;
import com.hziee.manage.sys.vo.UserLoginVo;

public interface UserService {

    UserEntity login(UserLoginVo userEntity);
}
