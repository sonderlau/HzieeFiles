package com.hziee.manage.sys.vo;

import lombok.Data;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

@Data
public class VersionsVo {
    private String current;
    private List<History> history;

    @Data
    public static class History{
        private String version;
    }
}
