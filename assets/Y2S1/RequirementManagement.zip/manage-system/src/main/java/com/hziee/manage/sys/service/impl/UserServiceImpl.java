package com.hziee.manage.sys.service.impl;

import com.hziee.manage.sys.dao.UserDao;
import com.hziee.manage.sys.entities.UserEntity;
import com.hziee.manage.sys.service.UserService;
import com.hziee.manage.sys.vo.UserLoginVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserDao userDao;

    @Override
    public UserEntity login(UserLoginVo userEntity) {
        return userDao.login(userEntity);
    }
}
