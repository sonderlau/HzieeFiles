package com.hziee.manage.sys.dao;

import com.hziee.manage.sys.entities.UserEntity;
import com.hziee.manage.sys.utils.R;
import com.hziee.manage.sys.vo.UserLoginVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserDao {

    @Select("select * from user where username = #{username} and password = #{password} ")
    UserEntity login(UserLoginVo userEntity);
}
