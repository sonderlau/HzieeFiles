package com.hziee.manage.sys.vo;

import lombok.Data;

@Data
public class UserLoginVo {
    private String username;
    private String password;


}
