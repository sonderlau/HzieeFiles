package com.hziee.manage.sys.entities;

import lombok.Data;


@Data
public class ProjectEntity {

    private Integer project_id;
    private String name;
    private Integer owner_id;
    private Integer requirement_id;
}
