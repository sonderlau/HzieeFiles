package HDOJ.week7;

        import java.util.Scanner;

public class D1161 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNext()){
            String str = sc.nextLine();
            str = str.toLowerCase();
            System.out.println(str);
        }
        sc.close();
    }
}
