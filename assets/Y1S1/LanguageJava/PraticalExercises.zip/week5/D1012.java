package HDOJ.week5;


public class D1012 {
    public static void main(String[] args) {
        System.out.println("n e");
        System.out.println("- -----------");
        System.out.println("0 1");
        System.out.println("1 2");
        System.out.println("2 2.5");
        System.out.println("3 2.666666667");
        System.out.println("4 2.708333333");
        System.out.println("5 2.716666667");
        System.out.println("6 2.718055556");
        System.out.println("7 2.718253968");
        System.out.println("8 2.718278770");
        System.out.println("9 2.718281526");
    }


    }


